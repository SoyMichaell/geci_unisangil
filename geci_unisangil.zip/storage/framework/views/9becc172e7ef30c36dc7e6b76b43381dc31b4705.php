<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/prueba/<?php echo e($resultado->id); ?>/editarresultado">Editar</a> / <a href="/prueba/mostrarresultado">Resultado
            programa</a> / <a href="/prueba">Pruebas saber</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-pencil-square-o"></i> Formulario de edición</h1>
    <?php $__env->startSection('message'); ?>
        <p>Diligenciar todos los campos requeridos.</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="tile">
            <h4><i class="fa fa-pencil"></i> Actualizar información</h4>
            <hr>
            <form action="/prueba/<?php echo e($resultado->prurepromo_id_prueba_programa); ?>/actualizarresultado" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row mb-3">
                    <div class="col-md-6 mb-3">
                        <label for="prurepro_year">Año *</label>
                        <input class="form-control <?php $__errorArgs = ['prurepro_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prurepro_year"
                            id="prurepro_year" value="<?php echo e($resultado->prurepro_year); ?>" type="number"
                            autocomplete="prurepro_year" autofocus required>
                        <?php $__errorArgs = ['prurepro_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="prurepromo_id_prueba_programa">Programa *</label>
                        <select class="form-select" name="prurepromo_id_prueba_programa"
                            id="prurepromo_id_prueba_programa" required>
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($programa->id); ?>"
                                    <?php echo e($programa->id == $resultado->prurepromo_id_prueba_programa ? 'selected' : ''); ?>>
                                    <?php echo e($programa->pro_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row mb">
                    <div class="col-md-6 mb-3">
                        <label for="prurepro_global_programa">Resultado global programa *</label>
                        <input class="form-control <?php $__errorArgs = ['prurepro_global_programa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="prurepro_global_programa" id="prurepro_global_programa"
                            value="<?php echo e($resultado->prurepro_global_programa); ?>" type="number"
                            autocomplete="prurepro_global_programa" autofocus required>
                        <?php $__errorArgs = ['prurepro_global_programa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="prurepro_global_institucion">Resultado global institución *</label>
                        <input class="form-control <?php $__errorArgs = ['prurepro_global_institucion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="prurepro_global_institucion" id="prurepro_global_institucion"
                            value="<?php echo e($resultado->prurepro_global_institucion); ?>" type="number"
                            autocomplete="prurepro_global_institucion" autofocus required>
                        <?php $__errorArgs = ['prurepro_global_institucion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6 mb-3">
                        <label for="prurepro_global_sede">Resultado global sede *</label>
                        <input class="form-control <?php $__errorArgs = ['prurepro_global_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="prurepro_global_sede" id="prurepro_global_sede"
                            value="<?php echo e($resultado->prurepro_global_sede); ?>" type="number"
                            autocomplete="prurepro_global_sede" autofocus required>
                        <?php $__errorArgs = ['prurepro_global_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="prurepro_global_grupo_referencia">Resultado global grupo referencia *</label>
                        <input class="form-control <?php $__errorArgs = ['prurepro_global_grupo_referencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="prurepro_global_grupo_referencia" id="prurepro_global_grupo_referencia"
                            value="<?php echo e($resultado->prurepro_global_grupo_referencia); ?>" type="number"
                            autocomplete="prurepro_global_grupo_referencia" autofocus required>
                        <?php $__errorArgs = ['prurepro_global_grupo_referencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultadox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <h5><?php echo e($resultadox->tipo_modulo_nombre); ?></h5>
                    <hr>
                    <div class="row mb-3">
                        <div class="col-md-3 mb-3 d-none">
                            <input class="form-control <?php $__errorArgs = ['prureprono_id_modulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="prureprono_id_modulo[]" id="prureprono_id_modulo"
                                value="<?php echo e($resultadox->prureprono_id_modulo); ?>" type="hidden"
                                autocomplete="prureprono_id_modulo" autofocus readonly>
                            <?php $__errorArgs = ['prureprono_id_modulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="prureprono_puntaje_programa">Programa *</label>
                            <input class="form-control <?php $__errorArgs = ['prureprono_puntaje_programa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="prureprono_puntaje_programa[]" id="prureprono_puntaje_programa"
                                value="<?php echo e($resultadox->prureprono_puntaje_programa); ?>" type="number"
                                autocomplete="prureprono_puntaje_programa" autofocus required>
                            <?php $__errorArgs = ['prureprono_puntaje_programa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="prureprono_puntaje_institucion">Institución *</label>
                            <input class="form-control <?php $__errorArgs = ['prureprono_puntaje_institucion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="prureprono_puntaje_institucion[]" id="prureprono_puntaje_institucion"
                                value="<?php echo e($resultadox->prureprono_puntaje_institucion); ?>" type="number"
                                autocomplete="prureprono_puntaje_institucion" autofocus required>
                            <?php $__errorArgs = ['prureprono_puntaje_institucion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="prureprono_puntaje_sede">Sede *</label>
                            <input class="form-control <?php $__errorArgs = ['prureprono_puntaje_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="prureprono_puntaje_sede[]" id="prureprono_puntaje_sede"
                                value="<?php echo e($resultadox->prureprono_puntaje_sede); ?>" type="number"
                                autocomplete="prureprono_puntaje_sede" autofocus required>
                            <?php $__errorArgs = ['prureprono_puntaje_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="prureprono_puntaje_grupo_referencia">Grupo referencia (NBC) *</label>
                            <input
                                class="form-control <?php $__errorArgs = ['prureprono_puntaje_grupo_referencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="prureprono_puntaje_grupo_referencia[]" id="prureprono_puntaje_grupo_referencia"
                                value="<?php echo e($resultadox->prureprono_puntaje_grupo_referencia); ?>" type="number"
                                autocomplete="prureprono_puntaje_grupo_referencia" autofocus required>
                            <?php $__errorArgs = ['prureprono_puntaje_grupo_referencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <div class="row mb-0">
                    <div class="col-md-12 offset-md-12">
                        <button type="submit" class="btn btn-success">
                            <?php echo e(__('Actualizar')); ?>

                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/prueba/general/edit.blade.php ENDPATH**/ ?>