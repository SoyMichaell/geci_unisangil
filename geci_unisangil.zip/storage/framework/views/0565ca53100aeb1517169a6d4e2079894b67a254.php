<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/prueba/crearsaberpro">Crear</a> / <a href="/prueba/mostrarsaberpro">Saber pro</a> / <a href="/prueba">Prueba</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-cubes"></i> Formulario de registro</h1>
    <?php $__env->startSection('message'); ?>
        <p>Diligenciar todos los campos requeridos.</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="tile">
            <h4><i class="fa fa-cube"></i> Registro prueba saber pro</h4><hr>
            <form action="/prueba/registrosaberpro" method="post">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <div class="col-md-6 mb-3">
                        <label for="prsapr_year">Año *</label>
                        <input class="form-control <?php $__errorArgs = ['prsapr_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prsapr_year"
                            id="prsapr_year" value="<?php echo e(old('prsapr_year')); ?>" type="number" autocomplete="prsapr_year"
                            autofocus required>
                        <?php $__errorArgs = ['prsapr_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="prsapr_periodo">Periodo *</label>
                        <input class="form-control <?php $__errorArgs = ['prsapr_periodo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="prsapr_periodo"
                            id="prsapr_periodo" value="<?php echo e(old('prsapr_periodo')); ?>" type="text"
                            autocomplete="prsapr_periodo" autofocus required>
                        <?php $__errorArgs = ['prsapr_periodo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6 mb-3">
                        <label for="prsapr_id_estudiante">Estudiante *</label>
                        <select class="form-control js-example-placeholder-single" name="prsapr_id_estudiante" id="prsapr_id_estudiante">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($estudiante->id); ?>">
                                    <?php echo e($estudiante->per_nombre . ' ' . $estudiante->per_apellido); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6 mb-3">
                        <label for="prsapr_numero_registro">Número de registro *</label>
                        <input class="form-control <?php $__errorArgs = ['prsapr_numero_registro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="prsapr_numero_registro" id="prsapr_numero_registro"
                            value="<?php echo e(old('prsapr_numero_registro')); ?>" type="text"
                            autocomplete="prsapr_numero_registro" autofocus required>
                        <?php $__errorArgs = ['prsapr_numero_registro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-4 mb-3">
                        <label for="prsapr_grupo_referencia">Grupo de referencia *</label>
                        <input class="form-control <?php $__errorArgs = ['prsapr_grupo_referencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="prsapr_grupo_referencia" id="prsapr_grupo_referencia"
                            value="<?php echo e(old('prsapr_grupo_referencia')); ?>" type="text"
                            autocomplete="prsapr_grupo_referencia" autofocus required>
                        <?php $__errorArgs = ['prsapr_grupo_referencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="prsapr_percentil_nacional">Percentil nacional *</label>
                        <input class="form-control <?php $__errorArgs = ['prsapr_percentil_nacional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="prsapr_percentil_nacional" id="prsapr_percentil_nacional"
                            value="<?php echo e(old('prsapr_percentil_nacional')); ?>" type="number"
                            autocomplete="prsapr_percentil_nacional" autofocus required>
                        <?php $__errorArgs = ['prsapr_percentil_nacional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-4 mb-3">
                        <label for="prsapr_percentil_grupo">Percentil grupo *</label>
                        <input class="form-control <?php $__errorArgs = ['prsapr_percentil_grupo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="prsapr_percentil_grupo" id="prsapr_percentil_grupo"
                            value="<?php echo e(old('prsapr_percentil_grupo')); ?>" type="number"
                            autocomplete="prsapr_percentil_grupo" autofocus required>
                        <?php $__errorArgs = ['prsapr_percentil_grupo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                    <?php $__currentLoopData = $tiposmodulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tiposmodulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                       <p> <h5><?php echo e($tiposmodulo->tipo_modulo_nombre); ?></h5><hr></p><br>
                       <div class="row mb-3">                       
                        <div class="col-md-3 mb-3 d-none">
                            <input class="form-control <?php $__errorArgs = ['prsaprmo_id_modulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="prsaprmo_id_modulo[]" id="prsaprmo_id_modulo" value="<?php echo e($tiposmodulo->id); ?>"
                                type="hidden" autocomplete="prsaprmo_id_modulo" autofocus readonly>
                            <?php $__errorArgs = ['prsaprmo_id_modulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="prsaprmo_puntaje">Puntaje *</label>
                            <input class="form-control <?php $__errorArgs = ['prsaprmo_puntaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="prsaprmo_puntaje[]" id="prsaprmo_puntaje" value="<?php echo e(old('prsaprmo_puntaje')); ?>"
                                type="number" autocomplete="prsaprmo_puntaje" autofocus required>
                            <?php $__errorArgs = ['prsaprmo_puntaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="prsaprmo_nivel_desempeno">Nivel desempeño *</label>
                            <input class="form-control <?php $__errorArgs = ['prsaprmo_nivel_desempeno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="prsaprmo_nivel_desempeno[]" id="prsaprmo_nivel_desempeno"
                                value="<?php echo e(old('prsaprmo_nivel_desempeno')); ?>" type="number"
                                autocomplete="prsaprmo_nivel_desempeno" autofocus required>
                            <?php $__errorArgs = ['prsaprmo_nivel_desempeno'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="prsaprmo_percentil_nacional">Percentil nacional *</label>
                            <input class="form-control <?php $__errorArgs = ['prsaprmo_percentil_nacional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="prsaprmo_percentil_nacional[]" id="prsaprmo_percentil_nacional"
                                value="<?php echo e(old('prsaprmo_percentil_nacional')); ?>" type="number"
                                autocomplete="prsaprmo_percentil_nacional" autofocus required>
                            <?php $__errorArgs = ['prsaprmo_percentil_nacional'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="prsaprmo_percentil_grupo">Percentil grupo *</label>
                            <input class="form-control <?php $__errorArgs = ['prsaprmo_percentil_grupo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="prsaprmo_percentil_grupo[]" id="prsaprmo_percentil_grupo"
                                value="<?php echo e(old('prsaprmo_percentil_grupo')); ?>" type="number"
                                autocomplete="prsaprmo_percentil_grupo" autofocus required>
                            <?php $__errorArgs = ['prsaprmo_percentil_grupo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <div class="row mb-3">
                    <div class="col-md-12 mb-3">
                        <label for="prsapr_novedad">Novedades</label>
                        <textarea class="form-control" name="prsapr_novedad" id="prsapr_novedad" cols="30"
                            rows="10"></textarea>
                        <?php $__errorArgs = ['prsapr_novedad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-0">
                    <div class="col-md-12 offset-md-12">
                        <button type="submit" class="btn btn-success">
                            <?php echo e(__('Registrar')); ?>

                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/prueba/saberpro/create.blade.php ENDPATH**/ ?>