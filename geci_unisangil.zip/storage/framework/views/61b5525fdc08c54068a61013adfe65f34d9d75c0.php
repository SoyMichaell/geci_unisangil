<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/programa">Programa</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-table"></i> Módulo programas</h1>
    <?php $__env->startSection('message'); ?>
        <p>Listado de registro programas académicos</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="col-md-12 tile">
            <div class="row">
                <div class="col-md-6">
                    <h4>Lista de registros</h4>
                </div>
                <div class="col-md-6 d-flex justify-content-end align-items-center">
                    <a class="btn btn-outline-danger" style="border-radius: 100%"
                        href="<?php echo e(url('programa/exportpdf')); ?>" title="Generar reporte pdf" target="_blank"><i
                            class="fa fa-file-pdf-o"></i></a>
                    <a class="btn btn-outline-success" style="border-radius: 100%"
                        href="<?php echo e(url('programa/exportexcel')); ?>" title="Generar reporte excel" target="_blank"><i
                            class="fa fa-file-excel-o"></i></a>
                    <a class="btn btn-outline-success" href="<?php echo e(url('programa/create')); ?>"><i
                            class="fa fa-plus-circle"></i>
                        Nuevo</a>
                </div>
            </div>
            <div class="table-responsive mt-2">
                <table class="table" id="tables">
                    <thead>
                        <tr>
                            <th>N°</th>
                            <th>Programa</th>
                            <th>Titulo</th>
                            <th style="width: 10%">Codigo SNIES</th>
                            <th>Nivel de formación</th>
                            <th>Metodologia</th>
                            <th>Director de programa</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($programa->pro_nombre); ?></td>
                                <td><?php echo e($programa->pro_titulo); ?></td>
                                <td><?php echo e($programa->pro_codigosnies); ?></td>
                                <td><?php echo e($programa->niveles->niv_nombre); ?></td>
                                <td><?php echo e($programa->metodologias->met_nombre); ?></td>
                                <td><?php echo e(Str::ucfirst($programa->directorprograma->per_nombre) .' ' .Str::ucfirst($programa->directorprograma->per_apellido)); ?>

                                </td>
                                <td>
                                    <form action="<?php echo e(route('programa.destroy', $programa->id)); ?>" method="POST">
                                        <div class="d-flex">
                                            <a class="btn btn-sm" href="/programa/<?php echo e($programa->id); ?>"><i
                                                    class="fa fa-folder-open"></i></a>
                                            <a class="btn btn-outline-info btn-sm "
                                                href="/programa/<?php echo e($programa->id); ?>/edit"><i
                                                    class="fa fa-refresh"></i></a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"><i
                                                    class="fa fa-trash"></i></button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/programa/index.blade.php ENDPATH**/ ?>