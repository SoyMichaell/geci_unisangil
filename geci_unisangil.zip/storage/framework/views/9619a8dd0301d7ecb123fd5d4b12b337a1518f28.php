
<?php $__env->startSection('title_report'); ?><p>EXTENSIÓN</p><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<img src="<?php echo e(public_path('image/logo.jpg')); ?>">
<p class="header_right">UNISANGIL<br><?php
    $fecha = date('Y-m-d');
    echo 'FECHA: '.$fecha;
?> <br>
    <?php
    if ($valor == 'actividadcultural') {
        echo 'MÓDULO: EXTENSIÓN | ACTIVIDAD CULTURAL';
    } elseif ($valor == 'consultoria') {
        echo 'MÓDULO: EXTENSIÓN | CONSULTORIA';
    } elseif ($valor == 'curso') {
        echo 'MÓDULO: EXTENSIÓN | CURSO';
    } elseif ($valor == 'educacioncontinua') {
        echo 'MÓDULO: EXTENSIÓN | EDUCACIÓN CONTINUA';
    } elseif ($valor == 'participante') {
        echo 'MÓDULO: EXTENSIÓN | PARTICIPANTE';
    } elseif ($valor == 'proyectoextension') {
        echo 'MÓDULO: EXTENSIÓN | PROYECTOS EXTENSIÓN';
    } elseif ($valor == 'servicioextension') {
        echo 'MÓDULO: EXTENSIÓN | SERVICIOS EXTENSIÓN';
    } elseif ($valor == 'fotografico') {
        echo 'MÓDULO: INTERNACIONALIZACIÓN | REGISTRO FOTOGRAFICO';
    } elseif ($valor == 'redacademica') {
        echo 'MÓDULO: INTERNACIONALIZACIÓN | REDES ACADÉMICAS';
    } elseif ($valor == 'redorganizacion') {
        echo 'MÓDULO: INTERNACIONALIZACIÓN | REDES DISCIPLINARIAS - ASOCIACIONES - ORGANIZACIONES';
    } elseif ($valor == 'curriculo') {
        echo 'MÓDULO: INTERNACIONALIZACIÓN | CURRICULO INTERNACIONAL';
    } elseif ($valor == 'eventovirtual') {
        echo 'MÓDULO: INTERNACIONALIZACIÓN | EVENTO VIRTUAL';
    } elseif ($valor == 'participacion') {
        echo 'MÓDULO: INTERNACIONALIZACIÓN | PARTICIPACIÓN EVENTOS';
    } elseif ($valor == 'einternacional') {
        echo 'MÓDULO: INTERNACIONALIZACIÓN | EVENTO INTERNACIONAL';
    } elseif ($valor == 'mnacional') {
        echo 'MÓDULO: EXTENSIÓN | MOVILIDAD NACIONAL';
    } elseif ($valor == 'mintersede') {
        echo 'MÓDULO: EXTENSIÓN | MOVILIDAD INTERSEDE';
    } elseif ($valor == 'minternacional') {
        echo 'MÓDULO: EXTENSIÓN | MOVILIDAD INTERNACIONAL';
    }
    ?></p>

<br>
<hr>
<?php if($valor == 'actividadcultural'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Año</th>
                <th>Semestre</th>
                <th>Cod. und organizacional</th>
                <th>Cod. actividad</th>
                <th>Fecha inicio</th>
                <th>Fecha final</th>
                <th>Valor nacional</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $actividad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($actividad->extcul_year); ?></td>
                    <td><?php echo e($actividad->extcul_semestre); ?></td>
                    <td><?php echo e($actividad->extcul_codigo_unidad_org); ?></td>
                    <td><?php echo e($actividad->extcul_codigo_actividad); ?></td>
                    <td><?php echo e($actividad->extcul_fecha_inicio); ?></td>
                    <td><?php echo e($actividad->extcul_fecha_fin); ?></td>
                    <td><?php echo e(number_format($actividad->extcul_valor_financiacion_nac, 2)); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'consultoria'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Año</th>
                <th>Semestre</th>
                <th>Cod. consultoria</th>
                <th>Entidad</th>
                <th>Valor</th>
                <th>Fecha inicio</th>
                <th>Fecha final</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consultoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($consultoria->extcon_year); ?></td>
                    <td><?php echo e($consultoria->extcon_semestre); ?></td>
                    <td><?php echo e($consultoria->extcon_codigo_consultoria); ?></td>
                    <td><?php echo e($consultoria->extcon_nombre_entidad); ?></td>
                    <td><?php echo e(number_format($consultoria->extcon_valor, 2)); ?></td>
                    <td><?php echo e($consultoria->extcon_fecha_inicio); ?></td>
                    <td><?php echo e($consultoria->extcon_fecha_fin); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'curso'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Año</th>
                <th>Semestre</th>
                <th>Cod. curso</th>
                <th>Nombre curso</th>
                <th>CINE</th>
                <th>Docente</th>
                <th>Estado</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($curso->extcurso_year); ?></td>
                    <td><?php echo e($curso->extcurso_semestre); ?></td>
                    <td><?php echo e($curso->extcurso_codigo); ?></td>
                    <td><?php echo e($curso->extcurso_nombre); ?></td>
                    <td><?php echo e($curso->cocide_nombre); ?></td>
                    <td><?php echo e($curso->per_nombre . ' ' . $curso->per_apellido); ?></td>
                    <td><?php echo e($curso->extcurso_estado); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'educacioncontinua'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Semestre</th>
                <th>Cod. curso</th>
                <th>No. de horas</th>
                <th>Tipo curso</th>
                <th>Valor curso</th>
                <th>Docente</th>
                <th>Tipo extensión</th>
                <th>Cantidad</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $educacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($educacion->extedu_semestre); ?></td>
                    <td><?php echo e($educacion->extedu_codigo_curso); ?></td>
                    <td><?php echo e($educacion->extedu_numero_horas); ?></td>
                    <td><?php echo e($educacion->extedu_tipo_curso); ?></td>
                    <td><?php echo e($educacion->extedu_valor_curso); ?></td>
                    <td><?php echo e($educacion->per_nombre . ' ' . $curso->per_apellido); ?></td>
                    <td><?php echo e($educacion->coarex_nombre); ?></td>
                    <td><?php echo e($educacion->extedu_cantidad); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'participante'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tipo documento</th>
                <th>No. documento</th>
                <th>Nombre completo</th>
                <th>Telefono</th>
                <th>Correo electronico personal</th>
                <th>Correo electronico institucional</th>
                <th>Dirección</th>
                <th>Cantidad</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($participante->per_tipo_documento); ?></td>
                    <td><?php echo e($participante->per_numero_documento); ?></td>
                    <td><?php echo e($participante->per_nombre . ' ' . $participante->per_apellido); ?></td>
                    <td><?php echo e($participante->per_telefono); ?></td>
                    <td><?php echo e($participante->per_correo); ?></td>
                    <td><?php echo e($participante->dop_correo_personal); ?></td>
                    <td><?php echo e($participante->dop_direccion); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'proyectoextension'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Año</th>
                <th>Semestre</th>
                <th>Cod. proyecto</th>
                <th>Nombre proyecto</th>
                <th>Valor</th>
                <th>Área de extensión</th>
                <th>Fecha de inicio</th>
                <th>Fecha final</th>
                <th>Nombre contacto</th>
                <th>Telefono</th>
                <th>Correo electronico</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $proyecto): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($proyecto->extprex_year); ?></td>
                    <td><?php echo e($proyecto->extprex_semestre); ?></td>
                    <td><?php echo e($proyecto->extprex_codigo_pr); ?></td>
                    <td><?php echo e($proyecto->extprex_nombre_pr); ?></td>
                    <td><?php echo e(number_format($proyecto->extprex_valor_pr, 2)); ?></td>
                    <td><?php echo e($proyecto->extprex_fecha_inicio); ?></td>
                    <td><?php echo e($proyecto->extprex_fecha_final); ?></td>
                    <td><?php echo e($proyecto->extprex_nombre_contacto . ' ' . $proyecto->extprex_apellido_contacto); ?></td>
                    <td><?php echo e($proyecto->extprex_telefono_contacto); ?></td>
                    <td><?php echo e($proyecto->extprex_correo_contacto); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'servicioextension'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Año</th>
                <th>Semestre</th>
                <th>Cod. proyecto</th>
                <th>Nombre proyecto</th>
                <th>Valor</th>
                <th>Área de extensión</th>
                <th>Fecha de inicio</th>
                <th>Fecha final</th>
                <th>Nombre contacto</th>
                <th>Telefono</th>
                <th>Correo electronico</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $servicio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($servicio->extseex_year); ?></td>
                    <td><?php echo e($servicio->extseex_semestre); ?></td>
                    <td><?php echo e($servicio->extseex_codigo_ser); ?></td>
                    <td><?php echo e($servicio->extseex_nombre_ser); ?></td>
                    <td><?php echo e(number_format($servicio->extseex_valor_ser, 2)); ?></td>
                    <td><?php echo e($servicio->extseex_fecha_inicio); ?></td>
                    <td><?php echo e($servicio->extseex_fecha_final); ?></td>
                    <td><?php echo e($servicio->extseex_nombre_contacto . ' ' . $servicio->extseex_apellido_contacto); ?></td>
                    <td><?php echo e($servicio->extseex_telefono_contacto); ?></td>
                    <td><?php echo e($servicio->extseex_correo_contacto); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'fotografico'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Año</th>
                <th>Periodo</th>
                <th>Tipo actividad</th>
                <th>Actividad</th>
                <th>Ente organizador</th>
                <th>Fecha</th>
                <th>Tipo evento</th>
                <th>Tipo modalidad</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fotografico): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($fotografico->extrefoin_year); ?></td>
                    <td><?php echo e($fotografico->extrefoin_periodo); ?></td>
                    <td><?php echo e($fotografico->extrefoin_tipo_actividad); ?></td>
                    <td><?php echo e($fotografico->extrefoin_actividad); ?></td>
                    <td><?php echo e($fotografico->extrefoin_ente_organizador); ?></td>
                    <td><?php echo e($fotografico->extrefoin_fecha); ?></td>
                    <td><?php echo e($fotografico->extrefoin_tipo_evento); ?></td>
                    <td><?php echo e($fotografico->extrefoin_tipo_modalidad); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'redacademica'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Año</th>
                <th>Periodo</th>
                <th>IES</th>
                <th>Caracter</th>
                <th>Fecha</th>
                <th>Logro (s)</th>
                <th>Resultado (s)</th>
                <th>Función</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $redacademica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($redacademica->exsered_year); ?></td>
                    <td><?php echo e($redacademica->exsered_periodo); ?></td>
                    <td><?php echo e($redacademica->exsered_ies); ?></td>
                    <td><?php echo e($redacademica->exsered_caracter); ?></td>
                    <td><?php echo e($redacademica->exsered_fecha); ?></td>
                    <td><?php echo e($redacademica->exsered_logros); ?></td>
                    <td><?php echo e($redacademica->exsered_resultados); ?></td>
                    <td><?php echo e($redacademica->exsered_funcion); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'redorganizacion'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Año</th>
                <th>Periodo</th>
                <th>Tipo</th>
                <th>Nombre</th>
                <th>Caracter</th>
                <th>Fecha</th>
                <th>Actividades</th>
                <th>Función</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $redorganizacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($redorganizacion->exseor_year); ?></td>
                    <td><?php echo e($redorganizacion->exseor_periodo); ?></td>
                    <td><?php echo e($redorganizacion->exseor_tipo); ?></td>
                    <td><?php echo e($redorganizacion->exseor_nombre); ?></td>
                    <td><?php echo e($redorganizacion->exseor_caracter); ?></td>
                    <td><?php echo e($redorganizacion->exseor_fecha); ?></td>
                    <td><?php echo e($redorganizacion->exseor_actividades); ?></td>
                    <td><?php echo e($redorganizacion->exseor_funcion); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'curriculo'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Año</th>
                <th>Periodo</th>
                <th>Asignatura</th>
                <th>Docente</th>
                <th>Idioma</th>
                <th>Uso tic</th>
                <th>Competencias globales</th>
                <th>Número estudiante</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $curriculo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($curriculo->exincu_year); ?></td>
                    <td><?php echo e($curriculo->exincu_periodo); ?></td>
                    <td><?php echo e($curriculo->asig_nombre); ?></td>
                    <td><?php echo e($curriculo->per_nombre . ' ' . $curriculo->per_apellido); ?></td>
                    <td><?php echo e($curriculo->ext_uso_idioma); ?></td>
                    <td><?php echo e($curriculo->ext_uso_tic); ?></td>
                    <td><?php echo e($curriculo->ext_competencia_global); ?></td>
                    <td><?php echo e($curriculo->ext_movilidad_estudiante); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'eventovirtual'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Nombre evento</th>
                <th>Fecha inicio</th>
                <th>Fecha fin</th>
                <th>Enlace ingreso</th>
                <th>Nombre ponente</th>
                <th>Institución</th>
                <th>País</th>
                <th>Ponencia</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($evento->exevir_nombre_evento); ?></td>
                    <td><?php echo e($evento->exevir_fecha_inicio); ?></td>
                    <td><?php echo e($evento->exevir_fecha_fin); ?></td>
                    <td><?php echo e($evento->exevir_enlace_ingreso); ?></td>
                    <td><?php echo e($evento->exevir_nombre_ponente); ?></td>
                    <td><?php echo e($evento->exevir_institucion_origen); ?></td>
                    <td><?php echo e($evento->exevir_pais); ?></td>
                    <td><?php echo e($evento->exevir_nombre_ponencia); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'participacion'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Año</th>
                <th>Periodo</th>
                <th>Tipo evento</th>
                <th>Nombre evento</th>
                <th>Fecha</th>
                <th>Organizador</th>
                <th>Tipo documento</th>
                <th>No. documento</th>
                <th>Nombre (s)</th>
                <th>Apellido (s)</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $participacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($participacion->expaev_year); ?></td>
                    <td><?php echo e($participacion->expaev_periodo); ?></td>
                    <td><?php echo e($participacion->expaev_tipo_evento); ?></td>
                    <td><?php echo e($participacion->expaev_nombre_evento); ?></td>
                    <td><?php echo e($participacion->expaev_fecha); ?></td>
                    <td><?php echo e($participacion->expaev_organizador); ?></td>
                    <td><?php echo e($participacion->per_tipo_documento); ?></td>
                    <td><?php echo e($participacion->per_numero_documento); ?></td>
                    <td><?php echo e($participacion->per_nombre); ?></td>
                    <td><?php echo e($participacion->per_apellido); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'einternacional'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tipo</th>
                <th>Año</th>
                <th>Periodo</th>
                <th>Nombre evento</th>
                <th>Fecha inicio</th>
                <th>Fecha fin</th>
                <th>Lugar</th>
                <th>Sede</th>
                <th>Ponente (s)</th>
                <th>País</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $einternacional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($einternacional->exevin_tipo); ?></td>
                    <td><?php echo e($einternacional->exevin_year); ?></td>
                    <td><?php echo e($einternacional->exevin_periodo); ?></td>
                    <td><?php echo e($einternacional->exevin_nombre_evento); ?></td>
                    <td><?php echo e($einternacional->exevin_fecha_inicio); ?></td>
                    <td><?php echo e($einternacional->exevin_fecha_final); ?></td>
                    <td><?php echo e($einternacional->exevin_lugar); ?></td>
                    <td><?php echo e($einternacional->exevin_sede); ?></td>
                    <td><?php echo e($einternacional->exevin_ponentes); ?></td>
                    <td><?php echo e($einternacional->exevin_pais); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'mnacional'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tipo</th>
                <th>Rol</th>
                <th>Sede</th>
                <th>Facultad</th>
                <th>Programa</th>
                <th>Nombre completo</th>
                <th>Tipo movilidad</th>
                <th>Fecha inicio</th>
                <th>Fecha fin</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mnacional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($mnacional->exmona_tipo); ?></td>
                    <td><?php echo e($mnacional->exmona_rol); ?></td>
                    <td><?php echo e($mnacional->mun_nombre); ?></td>
                    <td><?php echo e($mnacional->fac_nombre); ?></td>
                    <td><?php echo e($mnacional->pro_nombre); ?></td>
                    <td><?php echo e($mnacional->per_nombre . ' ' . $mnacional->per_apellido); ?></td>
                    <td><?php echo e($mnacional->exmona_tipo_movilidad); ?></td>
                    <td><?php echo e($mnacional->exmona_fecha_inicio); ?></td>
                    <td><?php echo e($mnacional->exmona_fecha_final); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'mintersede'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tipo</th>
                <th>Rol</th>
                <th>Sede origen</th>
                <th>Facultad origen</th>
                <th>Programa origen</th>
                <th>Nombre completo</th>
                <th>Tipo movilidad</th>
                <th>Fecha inicio</th>
                <th>Fecha fin</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mintersede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($mintersede->exmoin_tipo); ?></td>
                    <td><?php echo e($mintersede->exmoin_rol); ?></td>
                    <td><?php echo e($mintersede->mun_nombre); ?></td>
                    <td><?php echo e($mintersede->fac_nombre); ?></td>
                    <td><?php echo e($mintersede->pro_nombre); ?></td>
                    <td><?php echo e($mintersede->per_nombre . ' ' . $mintersede->per_apellido); ?></td>
                    <td><?php echo e($mintersede->exmoin_tipo_movilidad); ?></td>
                    <td><?php echo e($mintersede->exmoin_fecha_inicio); ?></td>
                    <td><?php echo e($mintersede->exmoin_fecha_final); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php elseif($valor == 'minternacional'): ?>
    <table class="table">
        <thead>
            <tr>
                <th>ID</th>
                <th>Tipo</th>
                <th>Rol</th>
                <th>Sede origen</th>
                <th>Facultad origen</th>
                <th>Programa origen</th>
                <th>Nombre completo</th>
                <th>Tipo movilidad</th>
                <th>Fecha inicio</th>
                <th>Fecha fin</th>
            </tr>
        </thead>
        <tbody>
            <?php $i = 1; ?>
            <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $minternacional): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($i++); ?></td>
                    <td><?php echo e($minternacional->exmointer_tipo); ?></td>
                    <td><?php echo e($minternacional->exmointer_rol); ?></td>
                    <td><?php echo e($minternacional->mun_nombre); ?></td>
                    <td><?php echo e($minternacional->fac_nombre); ?></td>
                    <td><?php echo e($minternacional->pro_nombre); ?></td>
                    <td><?php echo e($minternacional->per_nombre . ' ' . $minternacional->per_apellido); ?></td>
                    <td><?php echo e($minternacional->exmointer_tipo_movilidad); ?></td>
                    <td><?php echo e($minternacional->exmointer_fecha_inicio); ?></td>
                    <td><?php echo e($minternacional->exmointer_fecha_final); ?></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
<?php endif; ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reporte.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/reporte/extension.blade.php ENDPATH**/ ?>