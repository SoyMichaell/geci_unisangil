<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/prueba">Prueba</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-table"></i> Módulo Pruebas Saber</h1>
    <?php $__env->startSection('message'); ?>
        <p>Menu principal módulo pruebas saber </p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<style>
    .card__extension {
        width: 250px !important;
        border: 1px solid #cccc;
        padding: 15px;
        text-decoration: none;
        color: inherit;
        text-align: center;
        background: #fff;
        margin-left: 25px;
    }

</style>
<?php $__env->startSection('content'); ?>
    <div class="container bg-white p-3">
        <h4 class="fw-bold">Módulo pruebas saber</h4>
        <div class="row">
            <div class="col-md-12">
                <table class="table">
                    <tr>
                        <td>Registro tipo módulo</td> <td><a href="/prueba/mostrartipomodulo">Enlace</a> (<?php echo e($tipomodulos->count()); ?>)</td>
                    </tr>
                    <tr>
                        <td>Registro prueba saber 11</td> <td><a href="/prueba/mostrarsaber">Enlace</a> (<?php echo e($saber11->count()); ?>)</td>
                    </tr>
                    <tr>
                        <td>Registro prueba saber pro</td> <td><a href="/prueba/mostrarsaberpro">Enlace</a> (<?php echo e($saberpro->count()); ?>)</td>
                    </tr>
                    <tr>
                        <td>Resultados generales de programa</td> <td><a href="/prueba/mostrarresultado">Enlace</a></td>
                    </tr>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/prueba/index.blade.php ENDPATH**/ ?>