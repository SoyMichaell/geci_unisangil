<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/programa/create">Crear</a> / <a href="/programa">Programa</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-cubes"></i> Formulario de registro</h1>
    <?php $__env->startSection('message'); ?>
        <p>Diligenciar los campos requeridos, para el debido registro del docente.</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="tile w-100 mx-auto">
            <h4><i class="fa fa-cube"></i> Registro programa</h4>
            <hr>
            <form action="/programa" method="post">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="pro_estado_programa"><?php echo e(__('Estado programa')); ?></label>
                        <div class="row">
                            <div class="col-md-12">
                                <select class="form-control" name="pro_estado_programa" id="pro_estado_programa">
                                    <option selected>---- SELECCIONE ----</option>
                                    <?php $__currentLoopData = $estadoprogramas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estadoprograma): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($estadoprograma); ?>"><?php echo e($estadoprograma); ?>

                                        </option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label for="pro_departamento"><?php echo e(__('Departamento')); ?></label>
                        <select class="form-control" name="pro_departamento" id="pro_departamento">
                            <option selected>---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($departamento->id); ?>"><?php echo e($departamento->dep_nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="pro_municipio"><?php echo e(__('Municipio / sede')); ?></label>
                        <select class="form-control" name="pro_municipio" id="pro_municipio">
                            <option selected>---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($municipio->id); ?>"><?php echo e($municipio->mun_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="pro_facultad"><?php echo e(__('Facultad')); ?></label>
                        <select class="form-control" name="pro_facultad" id="pro_facultad">
                            <option selected>---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $facultades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facultad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($facultad->id); ?>"><?php echo e($facultad->fac_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="pro_nombre"><?php echo e(__('Programa *')); ?></label>
                        <input id="pro_nombre" type="text"
                            class="form-control <?php $__errorArgs = ['pro_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_nombre"
                            value="<?php echo e(old('pro_nombre')); ?>" autocomplete="pro_nombre" autofocus>
                        <?php $__errorArgs = ['pro_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="pro_codigosnies"><?php echo e(__('Código SNIES *')); ?></label>
                        <input id="pro_codigosnies" type="number"
                            class="form-control <?php $__errorArgs = ['pro_codigosnies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_codigosnies"
                            value="<?php echo e(old('pro_codigosnies')); ?>" autocomplete="pro_codigosnies" autofocus>
                        <?php $__errorArgs = ['pro_codigosnies'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="pro_resolucion"><?php echo e(__('Resolución *')); ?></label>
                        <input id="pro_resolucion" type="text"
                            class="form-control <?php $__errorArgs = ['pro_resolucion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_resolucion"
                            value="<?php echo e(old('pro_resolucion')); ?>" autocomplete="pro_resolucion" autofocus>
                        <?php $__errorArgs = ['pro_resolucion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="pro_titulo"><?php echo e(__('Titulo *')); ?></label>
                        <input id="pro_titulo" type="text"
                            class="form-control <?php $__errorArgs = ['pro_titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_titulo"
                            value="<?php echo e(old('pro_titulo')); ?>" autocomplete="pro_titulo" autofocus>
                        <?php $__errorArgs = ['pro_titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="pro_fecha_ult"><?php echo e(__('Fecha ultimo registro*')); ?></label>
                        <input id="pro_fecha_ult" type="date"
                            class="form-control <?php $__errorArgs = ['pro_fecha_ult'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_fecha_ult"
                            value="<?php echo e(old('pro_fecha_ult')); ?>" autocomplete="pro_fecha_ult" autofocus>
                        <?php $__errorArgs = ['pro_fecha_ult'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="pro_fecha_prox"><?php echo e(__('Fecha proximo registro *')); ?></label>
                        <input id="pro_fecha_prox" type="date"
                            class="form-control <?php $__errorArgs = ['pro_fecha_prox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="pro_fecha_prox"
                            value="<?php echo e(old('pro_fecha_prox')); ?>" autocomplete="pro_fecha_prox" autofocus>
                        <?php $__errorArgs = ['pro_fecha_prox'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="pro_nivel_formacion"><?php echo e(__('Nivel de formación ')); ?></label>
                        <select class="form-control" name="pro_nivel_formacion" id="pro_nivel_formacion">
                            <option selected>---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $niveles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nivel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($nivel->id); ?>"><?php echo e($nivel->niv_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="pro_programa_ciclos"><?php echo e(__('Progama por ciclos')); ?></label>
                        <select class="form-control" name="pro_programa_ciclos" id="pro_programa_ciclos">
                            <option selected>---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $programasCiclo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programaCiclo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($programaCiclo); ?>"><?php echo e($programaCiclo); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="pro_metodologia"><?php echo e(__('Metodologia ')); ?></label>
                        <select class="form-control" name="pro_metodologia" id="pro_metodologia">
                            <option selected>---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $metodologias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $metodologia): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($metodologia->id); ?>"><?php echo e($metodologia->met_nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="pro_duraccion"><?php echo e(__('Duracción programa (semestres)')); ?></label>
                        <select class="form-control" name="pro_duraccion" id="pro_duraccion">
                            <option selected>---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $duraccions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $duraccion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($duraccion); ?>"><?php echo e($duraccion); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="pro_periodo"><?php echo e(__('Periodo de admisión ')); ?></label>
                        <select class="form-control" name="pro_periodo" id="pro_periodo">
                            <option selected>---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $periodoAdmision; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($periodo); ?>"><?php echo e($periodo); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                    </div>
                    <div class="col-md-6">
                        <label for="pro_grupo_referencia"><?php echo e(__('Grupo de referencia *')); ?></label>
                        <input id="pro_grupo_referencia" type="text"
                            class="form-control <?php $__errorArgs = ['pro_grupo_referencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="pro_grupo_referencia" value="<?php echo e(old('pro_grupo_referencia')); ?>"
                            autocomplete="pro_grupo_referencia" autofocus>
                        <?php $__errorArgs = ['pro_grupo_referencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="pro_grupo_referencia_nbc"><?php echo e(__('Grupo de referencia (NBC) *')); ?></label>
                        <input id="pro_grupo_referencia_nbc" type="text"
                            class="form-control <?php $__errorArgs = ['pro_grupo_referencia_nbc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="pro_grupo_referencia_nbc" value="<?php echo e(old('pro_grupo_referencia_nbc')); ?>"
                            autocomplete="pro_grupo_referencia_nbc" autofocus>
                        <?php $__errorArgs = ['pro_grupo_referencia_nbc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="pro_norma"><?php echo e(__('Norma creación programa *')); ?></label>
                        <input id="pro_norma" type="text" class="form-control <?php $__errorArgs = ['pro_norma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="pro_norma" value="<?php echo e(old('pro_norma')); ?>" autocomplete="pro_norma" autofocus>
                        <?php $__errorArgs = ['pro_norma'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-12">
                        <label for="pro_director_programa"><?php echo e(__(' Director de programa ')); ?></label>
                        <select class="js-example-placeholder-single form-control" name="pro_director_programa"
                            id="pro_director_programa">
                            <option selected>---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $docentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $docente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($docente->id); ?>">
                                    <?php echo e($docente->per_nombre . ' ' . $docente->per_apellido); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <p class="<?php echo e($docentes->count()<=0 ? 'badge badge-danger' : ''); ?>"><?php echo e($docentes->count()<=0 ? 'No existen registro de directores de programa' : ''); ?></p>
                    </div>
                </div>
                <div class="row mb-0">
                    <div class="col-md-12 offset-md-12">
                        <button type="submit" class="btn btn-success">
                            <?php echo e(__('Registrar')); ?>

                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/programa/create.blade.php ENDPATH**/ ?>