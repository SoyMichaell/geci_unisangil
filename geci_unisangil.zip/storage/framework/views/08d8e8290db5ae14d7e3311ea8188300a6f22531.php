
<?php $__env->startSection('title_report'); ?><p>ESTUDIANTES</p><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<img src="<?php echo e(public_path('image/logo.jpg')); ?>">
<p class="header_right">UNISANGIL <br><?php
    $fecha = date('Y-m-d');
    echo 'FECHA: '.$fecha;
?> <br>MÓDULO: ESTUDIANTES</p>
<?php if($nombre_datos != '' || $nombre_datos != null): ?>
    <p class="titulo__header">Estudiantes: <?php echo e($nombre_datos->pro_nombre); ?> </p>
<?php endif; ?>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Tipo documento</th>
            <th>No. documento</th>
            <th>Nombre (s)</th>
            <th>Apellido (s)</th>
            <th>Correo electronico</th>
            <?php if($nombre_datos != '' || $nombre_datos != null): ?>
                <td>Semestre</td>
            <?php else: ?>
                <td>Programa</td>
            <?php endif; ?>
            <th>Tipo financiamiento</th>
            <th>Año de ingreso</th>
            <th>Tipo de matricula</th>
        </tr>
    </thead>
    <tbody>
        <?php $i = 1; ?>
        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($estudiante->per_tipo_documento); ?></td>
                <td><?php echo e($estudiante->per_numero_documento); ?></td>
                <td><?php echo e($estudiante->per_nombre); ?></td>
                <td><?php echo e($estudiante->per_apellido); ?></td>
                <td><?php echo e($estudiante->per_correo); ?></td>
                <?php if($nombre_datos != '' || $nombre_datos != null): ?>
                    <td><?php echo e($estudiante->estu_semestre); ?></td>
                <?php else: ?>
                    <td><?php echo e($estudiante->pro_nombre); ?></td>
                <?php endif; ?>
                <td><?php echo e($estudiante->estu_financiamiento); ?></td>
                <td><?php echo e($estudiante->estu_ingreso); ?></td>
                <td><?php echo e($estudiante->estu_tipo_matricula); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('reporte.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/reporte/estudiante.blade.php ENDPATH**/ ?>