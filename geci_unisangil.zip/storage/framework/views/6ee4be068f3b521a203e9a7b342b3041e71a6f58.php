<!doctype html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- CSRF Token -->
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

    <link rel="shortcut icon" href="<?php echo e(asset('image/favicon.png')); ?>" type="image/x-icon">
    <title><?php echo e('UNISANGIL'); ?></title>

    <!-- Scripts -->
    <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

    <!-- Styles -->
    <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">

    <!--DataTables -->
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('DataTables/datatables.min.css')); ?>">

    <!--Select2-->
    <link href="<?php echo e(asset('css/select2.min.css')); ?>" rel="stylesheet" />
</head>

<body class="app sidebar-mini" style="background-color: var(--bs-gray-200);">
    <?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <header class="app-header"><a class="app-header__logo" href="<?php echo e(url('home')); ?>">GIC<span>PAC</span></a>
        <a class="app-sidebar__toggle" href="#" data-toggle="sidebar" aria-label="Hide Sidebar"></a>
        <ul class="app-nav">
            <li class="dropdown"><a class="app-nav__item" href="#" data-toggle="dropdown"
                    aria-label="Open Profile Menu"><i class="fa fa-user fa-lg"></i></a>
                <ul class="dropdown-menu settings-menu dropdown-menu-right">
                    <li><a class="dropdown-item" href="/usuario/<?php echo e(auth()->user()->id); ?>/profile"><i class="fa fa-users fa-lg"></i>
                            Perfil</a>
                    </li>
                    <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>" onclick="event.preventDefault();
                        document.getElementById('logout-form').submit();"><i class="fa fa-sign-out fa-lg"></i>
                            Salir</a>
                    </li>
                    <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" class="d-none">
                        <?php echo csrf_field(); ?>
                    </form>
                </ul>
            </li>
        </ul>
    </header>
    <div class="app-sidebar__overlay" data-toggle="sidebar"></div>
    <aside class="app-sidebar">
        <div class="app-sidebar__user">
            <div>
                <p class="app-sidebar__user-name">
                    <?php echo e(Str::ucfirst(auth()->user()->per_nombre . ' ' . auth()->user()->per_apellido)); ?>

                </p>
                <p class="app-sidebar__user-designation"><?php echo e(auth()->user()->tiposusuario->tip_nombre); ?></p>
            </div>
        </div>
        <ul class="app-menu">
            <li><a class="app-menu__item active" href="<?php echo e(url('home')); ?>"><i class="app-menu__icon fa fa-dashboard"
                        data-toggle="modal" data-target="#roles"></i><span class="app-menu__label">Dashboard</span></a>
            </li>
            <?php if(Auth::user()->per_tipo_usuario == 1): ?>
            <li class="treeview"><a class="app-menu__item" href="" data-toggle="treeview"><i
                        class="app-menu__icon fa fa-users"></i><span class="app-menu__label">Registro de usuarios</span><i
                        class="treeview-indicator fa fa-angle-right"></i></a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="<?php echo e(url('usuario/create')); ?>"><i
                                class="icon fa fa-circle-o"></i>
                            Usuarios</a></li>
                </ul>
            </li>
            <li class="treeview"><a class="app-menu__item" href="" data-toggle="treeview"><i
                        class="app-menu__icon fa fa-cog"></i><span class="app-menu__label">Configuración</span><i
                        class="treeview-indicator fa fa-angle-right"></i></a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="<?php echo e(url('departamento')); ?>"><i
                                class="icon fa fa-circle-o"></i>
                            Departamentos</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('municipio')); ?>"><i class="icon fa fa-circle-o"></i>
                            Municipios</a>
                    </li>
                    <li><a class="treeview-item" href="<?php echo e(url('facultad')); ?>"><i class="icon fa fa-circle-o"></i>
                            Facultades</a>
                    </li>
                    <li><a class="treeview-item" href="<?php echo e(url('nivelformacion')); ?>"><i
                                class="icon fa fa-circle-o"></i> Nivel de formación</a>
                    </li>
                    <li><a class="treeview-item" href="<?php echo e(url('metodologia')); ?>"><i class="icon fa fa-circle-o"></i>
                            Metodologia</a>
                    </li>
                </ul>
            </li>
            <?php endif; ?>
            <li class="treeview"><a class="app-menu__item" href="#" data-toggle="treeview"><i
                        class="app-menu__icon fa fa-th-list"></i><span class="app-menu__label">Módulos</span><i
                        class="treeview-indicator fa fa-angle-right"></i></a>
                <ul class="treeview-menu">
                    <li><a class="treeview-item" href="<?php echo e(url('programa')); ?>"><i class="icon fa fa-circle-o"></i>
                            Programas</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('estudiante')); ?>"><i class="icon fa fa-circle-o"></i>
                            Estudiantes</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('docente')); ?>"><i class="icon fa fa-circle-o"></i>
                            Docentes</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('prueba')); ?>"><i class="icon fa fa-circle-o"></i>
                            Pruebas saber</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('trabajo')); ?>"><i class="icon fa fa-circle-o"></i>
                            Trabajo de grado</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('software')); ?>"><i class="icon fa fa-circle-o"></i>
                            TIC'S</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('extension')); ?>"><i class="icon fa fa-circle-o"></i>
                            Extensión e Internacialización</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('red')); ?>"><i class="icon fa fa-circle-o"></i>
                            Redes acádemicas</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('laboratorio')); ?>"><i class="icon fa fa-circle-o"></i>
                            Laboratorios</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('movilidad')); ?>"><i class="icon fa fa-circle-o"></i>
                            Movilidad</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('convenio')); ?>"><i class="icon fa fa-circle-o"></i>
                            Convenio</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('bienestar')); ?>"><i class="icon fa fa-circle-o"></i>
                            Bienestar Institucional</a></li>
                    <li><a class="treeview-item" href="<?php echo e(url('investigacion')); ?>"><i
                                class="icon fa fa-circle-o"></i>
                            Investigación</a></li>
                </ul>
            </li>
        </ul>
    </aside>

    <main class="app-content">
        <div class="app-title">
            <div>
                <?php echo $__env->yieldContent('title'); ?>
                <?php echo $__env->yieldContent('message'); ?>
            </div>
            <ul class="app-breadcrumb breadcrumb">
                <li class="breadcrumb-item"><a href="#"><?php echo $__env->yieldContent('navegar'); ?></a></li>
                <li class="breadcrumb-item"><a href="/home"><i class="fa fa-home fa-lg"></i></a></li>
            </ul>
        </div>
        <?php echo $__env->yieldContent('content'); ?>
    </main>

    <script src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.6.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-fQybjgWLrvvRgtW6bFlB7jaZrFsaBXjsOMm/tB9LTS58ONXgqbR9W8oWht/amnpF" crossorigin="anonymous">
    </script>
    <script src="https://use.fontawesome.com/6c8ac1ea46.js"></script>
    <?php echo $__env->yieldContent('scripts'); ?>

    <script src="<?php echo e(asset('js/dataTable.js')); ?>"></script>
    <script type="text/javascript" charset="utf8" src="<?php echo e(asset('DataTables/datatables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('js/select2.min.js')); ?>"></script>
    <script type="text/javascript">
        $(document).ready(function() {
            $('#tables').DataTable();
            $('.js-example-placeholder-single').select2();

            $('.js-example-basic-multiple').select2();
        });
    </script>




    <script src="<?php echo e(asset('js/main.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/layouts/app.blade.php ENDPATH**/ ?>