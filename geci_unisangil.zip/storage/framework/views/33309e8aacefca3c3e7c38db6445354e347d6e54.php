<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/prueba/mostrartipomodulo">Tipo módulo</a> / <a href="/prueba">Pruebas saber</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-cubes"></i> Formulario de registro</h1>
    <?php $__env->startSection('message'); ?>
        <p>Diligenciar todos los campos requeridos.</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class=" <?php echo e(Auth::user()->per_tipo_usuario == 4 ? 'col-md-12' : 'col-md-12'); ?> tile">
                <h4>Listado módulos</h4>
                <table class="table" id="tables">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Módulo</th>
                            <th>Tipo prueba</th>
                            <th style="width: 7%">Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $tipomodulos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipomodulo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($tipomodulo->tipo_modulo_nombre); ?></td>
                                <td><?php echo e($tipomodulo->pruebas->tipo_prueba_nombre); ?></td>
                                <td>
                                    <form action="/prueba/<?php echo e($tipomodulo->id); ?>/eliminartipomodulo" method="POST">
                                        <div class="d-flex justify-content-center">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"><i
                                                    class="fa fa-trash"></i></button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
            <div class="col-md-12 tile">
                <h4><i class="fa fa-cube"></i> Registro módulos pruebas</h4>
                <form action="/prueba/registrotipomodulo" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <div class="col-md-12 mt-2">
                            <label for="tipo_modulo_nombre"><?php echo e(__('Nombre tipo módulo *')); ?></label>
                            <input id="tipo_modulo_nombre" type="text"
                                class="form-control <?php $__errorArgs = ['tipo_modulo_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="tipo_modulo_nombre" value="<?php echo e(old('tipo_modulo_nombre')); ?>"
                                autocomplete="tipo_modulo_nombre">
                            <?php $__errorArgs = ['tipo_modulo_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mt-2">
                            <label for="tipo_modulo_id_prueba"><?php echo e(__('Nombre tipo módulo *')); ?></label>
                            <select class="form-control <?php $__errorArgs = ['tipo_modulo_id_prueba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="tipo_modulo_id_prueba" id="tipo_modulo_id_prueba">
                                <option value="">---- SELECCIONE ----</option>
                                <?php $__currentLoopData = $tipospruebas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prueba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($prueba->id); ?>"><?php echo e($prueba->tipo_prueba_nombre); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <p class="<?php echo e($tipospruebas->count()<=0 ? 'badge badge-danger' : ''); ?>"><?php echo e($tipospruebas->count()<=0 ? 'No existen registros de pruebas' : ''); ?></p>
                            <?php $__errorArgs = ['tipo_modulo_id_prueba'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-0 mt-2">
                        <div class="col-md-12 offset-md-12">
                            <button type="submit" class="btn btn-success">
                                <?php echo e(__('Registrar')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/prueba/tipomodulo/index.blade.php ENDPATH**/ ?>