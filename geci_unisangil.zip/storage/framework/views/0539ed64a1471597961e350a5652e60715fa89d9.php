<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-table"></i> Horarios asignatura</h1>
        <p>Listado horario asignaturas</p>
    <?php $__env->startSection('message'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive tile mt-2">
                    <div class="row mb-3">
                        <div class="col-md-7">
                            <h4>Listado registro horario</h4>
                        </div>
                        <div class="col-md-5 d-flex justify-content-end align-items-center">
                            <a class="btn btn-outline-success" href="/programa/crearhorario"><i
                                    class="fa fa-plus-circle"></i>
                                Nuevo</a>
                        </div>
                    </div>
                    <table class="table table-bordered" id="tables">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Año</th>
                                <th>Semestre</th>
                                <th>Código asignatura</th>
                                <th>Grupo</th>
                                <th>Docente</th>
                                <th>Horario</th>
                                <th>Aula</th>
                                <th>Nro. horas semana docencia</th>
                                <th>Nro. horas semana investigación</th>
                                <th>Nro. horas semana extensión</th>
                                <th>Nro. horas semana labores administrativas</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $horarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $horario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($horario->pph_year); ?></td>
                                    <td><?php echo e($horario->pph_semestre); ?></td>
                                    <td><?php echo e($horario->asignaturas->asig_nombre); ?></td>
                                    <td><?php echo e($horario->pph_grupo); ?></td>
                                    <td><?php echo e($horario->docentes->per_nombre . ' ' . $horario->docentes->per_apellido); ?>

                                    </td>
                                    <td><?php echo e($horario->pph_horario); ?></td>
                                    <td><?php echo e($horario->pph_aula); ?></td>
                                    <td><?php echo e($horario->pph_nro_horas_semana_docencia); ?></td>
                                    <td><?php echo e($horario->pph_nro_horas_semana_investigacion); ?></td>
                                    <td><?php echo e($horario->pph_nro_horas_semana_extension); ?></td>
                                    <td><?php echo e($horario->pph_nro_horas_semana_administrativas); ?></td>
                                    <td>
                                        <form action="/programa/<?php echo e($horario->id); ?>/eliminarhorario" method="POST">
                                            <div class="d-flex">
                                                <a class="btn btn-outline-info btn-sm"
                                                    href="<?php echo e(url('programa/' . $horario->id . '/editarhorario')); ?>"
                                                    title="Editar registro"><i
                                                        class="fa-solid fa-pen-to-square"></i></a>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button class="btn btn-danger btn-sm" type="submit"><i
                                                        class="fa-solid fa-trash"></i></button>
                                            </div>
                                        </form>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/programa/horario/index.blade.php ENDPATH**/ ?>