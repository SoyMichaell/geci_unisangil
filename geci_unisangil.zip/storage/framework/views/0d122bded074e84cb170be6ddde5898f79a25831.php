<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/prueba/mostrarsaberpro">Saber pro</a> / <a href="/prueba">Prueba</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-table"></i> Módulo pruebas saber Pro</h1>
    <?php $__env->startSection('message'); ?>
        <p>Listado pruebas saber pro</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="tile">
            <div class="row">
                <div class="col-md-6">
                    <h4>Listado pruebas saber pro</h4>
                </div>
                <div class="col-md-6 d-flex justify-content-end">
                    <a class="btn btn-outline-success" href="/prueba/crearsaberpro"><i
                            class="fa fa-plus-circle"></i>
                        Nuevo</a>
                </div>
            </div>
            <br>
            <table class="table table-bordered" id="tables">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Año presentación</th>
                        <th>Periodo</th>
                        <th>Estudiante</th>
                        <th>Número de registro</th>
                        <th>Grupo de referencia</th>
                        <th>Puntaje global</th>
                        <th>Percentil nacional</th>
                        <th>Percentil grupo</th>
                        <th style="width: 7%">Acciones</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $i = 1; ?>
                    <?php $__currentLoopData = $pros; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pro): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($i++); ?></td>
                            <td><?php echo e($pro->prsapr_year); ?></td>
                            <td><?php echo e($pro->prsapr_periodo); ?></td>
                            <td><?php echo e($pro->per_nombre . ' ' . $pro->per_apellido); ?></td>
                            <td><?php echo e($pro->prsapr_numero_registro); ?></td>
                            <td><?php echo e($pro->prsapr_grupo_referencia); ?></td>
                            <td><?php echo e($pro->prsapr_puntaje_global); ?></td>
                            <td><?php echo e($pro->prsapr_percentil_nacional); ?></td>
                            <td><?php echo e($pro->prsapr_percentil_grupo); ?></td>
                            <td>
                                <form action="/prueba/<?php echo e($pro->prsapr_id_estudiante); ?>/eliminarsaberpro"
                                    method="POST">
                                    <div class="d-flex justify-content-center">
                                        <a class="btn btn-sm"
                                            href="/prueba/<?php echo e($pro->prsapr_id_estudiante); ?>/versaberpro"><i
                                                class="fa fa-folder-open"></i></a>
                                        <a class="btn btn-outline-info  btn-sm"
                                            href="/prueba/<?php echo e($pro->prsapr_id_estudiante); ?>/editarsaberpro"><i
                                                class="fa fa-edit"></i></a>
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm"><i
                                                class="fa fa-trash"></i></button>
                                    </div>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/prueba/saberpro/index.blade.php ENDPATH**/ ?>