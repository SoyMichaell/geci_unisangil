<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/software">Software</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-table"></i> Módulo TIC'S</h1>
    <?php $__env->startSection('message'); ?>
        <p>Listado de registro software en uso</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="d-flex">
            <a class="btn btn-success" href="<?php echo e(url('software/mostrarrecurso')); ?>"><i class="fa fa-plus-circle"></i>
                Recursos tecnológicos</a>
        </div>
        <div class="tile col-md-12 mt-2">
            <div class="row">
                <div class="col-md-6">
                    <h4>Lista de registros</h4>
                </div>
                <div class="col-md-6 d-flex justify-content-end align-items-center">
                    <a class="btn btn-outline-danger" style="border-radius: 100%"
                        href="<?php echo e(url('software/exportpdf')); ?>" title="Generar reporte pdf" target="_blank"><i
                            class="fa fa-file-pdf-o"></i></a>
                    <a class="btn btn-outline-success" style="border-radius: 100%"
                        href="<?php echo e(url('software/exportexcel')); ?>" title="Generar reporte excel"><i
                            class="fa fa-file-excel-o"></i></a>
                    <a class="btn btn-outline-success" href="<?php echo e(url('software/create')); ?>"><i
                            class="fa fa-plus-circle"></i>
                        Nuevo</a>
                </div>
            </div>
            <div class="table-responsive mt-2">
                <table class="table" id="tables">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Tipo software</th>
                            <th>Software</th>
                            <th>Desarrollador</th>
                            <th>Versión</th>
                            <th>Año adquisición licencia</th>
                            <th>Año vencimiento licencia</th>
                            <th>Programa</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $softwares; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $software): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($software->sof_tipo); ?></td>
                                <td><?php echo e($software->sof_nombre); ?></td>
                                <td><?php echo e($software->sof_desarrollador); ?></td>
                                <td><?php echo e($software->sof_version); ?></td>
                                <td><?php echo e($software->sof_year_ad_licencia); ?></td>
                                <td><?php echo e($software->sof_year_ve_licencia); ?></td>
                                <td><?php echo e($software->sof_id_programa); ?></td>
                                <td>
                                    <form action="<?php echo e(route('software.destroy', $software->id)); ?>" method="POST">
                                        <div class="d-flex">
                                            <a class="btn btn-sm" href="/software/<?php echo e($software->id); ?>"><i
                                                    class="fa fa-folder-open"></i></a>
                                            <a class="btn btn-outline-info btn-sm "
                                                href="/software/<?php echo e($software->id); ?>/edit"><i
                                                    class="fa fa-refresh"></i></a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"><i
                                                    class="fa fa-trash"></i></button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/software/index.blade.php ENDPATH**/ ?>