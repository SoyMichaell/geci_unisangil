
<?php $__env->startSection('title'); ?>
    <h1 class="titulo"><i class="fa fa-tachometer"></i> Bienvenido (a),
        <?php echo e(Str::ucfirst(auth()->user()->per_nombre . ' ' . auth()->user()->per_apellido)); ?> </h1>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid ">
        <?php if(Auth::user()->per_tipo_usuario == 1 || Auth::user()->per_tipo_usuario == 2): ?>
            <div class="row mb-3">
                <div class="col-md-4 col-lg-3">
                    <div class="widget-small info coloured-icon"><i class="icon fa fa-book fa-3x"></i>
                        <div class="info">
                            <h4>Plan de estudio</h4>
                            <a href="/programa/mostrarplan">Crear</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-3">
                    <div class="widget-small info coloured-icon"><i class="icon fa fa-bookmark fa-3x"></i>
                        <div class="info">
                            <h4>Asignaturas</h4>
                            <a href="/programa/mostrarasignatura">Crear</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-3">
                    <div class="widget-small info coloured-icon"><i class="icon fa fa-calendar fa-3x"></i>
                        <div class="info">
                            <h4>Horario</h4>
                            <a href="/programa/mostrarhorario">Crear</a>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-3">
                    <div class="widget-small info coloured-icon"><i class="icon fa fa-user fa-3x"></i>
                        <div class="info">
                            <h4>Estudiantes</h4>
                            <p><b>(<?php echo e($estudiantes->count()); ?>)</b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-3">
                    <div class="widget-small info coloured-icon"><i class="icon fa fa-user fa-3x"></i>
                        <div class="info">
                            <h4>Director de programa</h4>
                            <p><b>(<?php echo e($directores->count()); ?>)</b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-3">
                    <div class="widget-small info coloured-icon"><i class="icon fa fa-user fa-3x"></i>
                        <div class="info">
                            <h4>Docentes</h4>
                            <p><b>(<?php echo e($docentes->count()); ?>)</b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-3">
                    <div class="widget-small info coloured-icon"><i class="icon fa fa-graduation-cap fa-3x"></i>
                        <div class="info">
                            <h4>Egresados</h4>
                            <p><b>(<?php echo e($egresados->count()); ?>)</b></p>
                        </div>
                    </div>
                </div>
                <div class="col-md-4 col-lg-3">
                    <div class="widget-small info coloured-icon"><i class="icon fa fa-user fa-3x"></i>
                        <div class="info">
                            <h4>Personal administrativo</h4>
                            <p><b>(<?php echo e($administrativos->count()); ?>)</b>

                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <?php if(Auth::user()->per_tipo_usuario == 2): ?>
            <div class="alert alert-primary" role="alert">
                <strong>Complementar información docente <a
                        href="<?php echo e(url('docente/' . auth()->user()->id . '/directorcompletar')); ?>">Completar</a></strong>
            </div>
        <?php endif; ?>
        <?php if(Auth::user()->per_tipo_usuario == 1): ?>
            <div class="tile col-md-12 mt-2">
                <div class="row">
                    <div class="col-md-6">
                        <h4 class="titulo">Usuarios en plataforma</h4>
                    </div>
                </div>
                <div class="table-responsive mt-3">
                    <table class="table table-bordered" id="tables">
                        <thead>
                            <tr>
                                <th>N°</th>
                                <th>Tipo documento</th>
                                <th>Número documento</th>
                                <th>Nombre (s)</th>
                                <th>Apellido (s)</th>
                                <th>Correo electronico</th>
                                <th>Telefono</th>
                                <th>Tipo de usuario</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $i = 1; ?>
                            <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($i++); ?></td>
                                    <td><?php echo e($persona->per_tipo_documento); ?></td>
                                    <td><?php echo e($persona->per_numero_documento); ?></td>
                                    <td><?php echo e($persona->per_nombre); ?> </td>
                                    <td><?php echo e($persona->per_apellido); ?></td>
                                    <td><?php echo e($persona->per_correo); ?></td>
                                    <td><?php echo e($persona->per_telefono); ?></td>
                                    <td><?php echo e($persona->tip_nombre); ?></td>
                                    <td>
                                        <?php if(Auth::user()->id == $persona->id): ?>
                                            <p class="badge badge-success">Activo</p>
                                        <?php else: ?>
                                            <form action="<?php echo e(url("usuario/{$persona->id}")); ?>" method="POST">
                                                <div class="d-flex">
                                                    <?php if(Auth::user()->per_tipo_usuario == 1 || Auth::user()->per_tipo_usuario == 2): ?>
                                                        <a class="btn btn-info btn-sm"
                                                            href="usuario/<?php echo e($persona->id); ?>/profile"><i
                                                                class="fa fa-edit"></i></a>
                                                        <?php if($persona->per_id_estado == 'activo'): ?>
                                                            <a class="btn btn-danger btn-sm"
                                                                href="usuario/<?php echo e($persona->id); ?>/actualizarestado">Inactivar</a>
                                                        <?php else: ?>
                                                            <a class="btn btn-success btn-sm"
                                                                href="usuario/<?php echo e($persona->id); ?>/actualizarestado">Activar</a>
                                                        <?php endif; ?>
                                                        <?php echo csrf_field(); ?>
                                                        <?php echo method_field('DELETE'); ?>
                                                        <button type="submit" class="btn btn-outline-danger btn-sm"><i
                                                                class="fa fa-trash"></i></button>
                                                    <?php endif; ?>
                                                </div>
                                            </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
        <?php endif; ?>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/home.blade.php ENDPATH**/ ?>