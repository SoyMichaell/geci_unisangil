<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/docente/<?php echo e($persona->id); ?>/directorcompletar">Completar información</a> / <a href="/docente">Docente</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-pencil-square-o"></i> Formulario de edición</h1>
    <?php $__env->startSection('message'); ?>
        <p>Diligenciar todos los campos requeridos.</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <ul class="nav nav-tabs" id="myTab" role="tablist">
            <li class="nav-item" role="presentation">
                <button class="nav-link <?php echo e($cuenta > 0 ? ($docente->id_proceso == 1 ? 'active' : '') : 'active'); ?>" id="informacion-tab" data-bs-toggle="tab" data-bs-target="#informacion" type="button" role="tab"
                    aria-controls="informacion" aria-selected="true">Información</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link <?php echo e($cuenta > 0 ? ($docente->id_proceso == 2 ? 'active' : '') : 'active'); ?>" id="estudio-tab" data-bs-toggle="tab" data-bs-target="#estudio" type="button" role="tab"
                    aria-controls="estudio" aria-selected="true">Estudios</button>
            </li>
            <li class="nav-item" role="presentation">
                <button class="nav-link <?php echo e($cuenta > 0 ? ($docente->id_proceso == 3 ? 'active' : '') : 'active'); ?>" id="zip-tab" data-bs-toggle="tab" data-bs-target="#zip" type="button" role="tab"
                    aria-controls="zip" aria-selected="true">.Zip</button>
            </li>
        </ul>
        <div class="tab-content" id="myTabContent">
            <div class="tab-pane <?php echo e($cuenta > 0 ? ($docente->id_proceso == 1 ? 'show active' : '') : 'show active'); ?> tile p-3" id="informacion" role="tabpanel" aria-labelledby="informacion-tab">
                <form
                    action="/docente/<?php echo e($persona->id); ?>/actualizarinformacion"
                    method="post">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <input type="hidden" value="<?php echo e($persona->id); ?>" name="id" id="id" readonly>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="ciudad_procedencia"><?php echo e(__('Ciudad de procedencia *')); ?></label>
                            <input id="ciudad_procedencia" type="text"
                                class="form-control <?php $__errorArgs = ['ciudad_procedencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="ciudad_procedencia"
                                value="<?php echo e($cuenta > 0 ? ($docente->ciudad_procedencia == "" ? old('ciudad_procedencia') : $docente->ciudad_procedencia) : old('ciudad_procedencia')); ?>"
                                autocomplete="ciudad_procedencia" autofocus>
                            <?php $__errorArgs = ['ciudad_procedencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="correo_personal"><?php echo e(__('Correo personal *')); ?></label>
                            <input id="correo_personal" type="email"
                                class="form-control <?php $__errorArgs = ['correo_personal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="correo_personal"
                                value="<?php echo e($cuenta > 0 ? ($docente->correo_personal == "" ? old('correo_personal') : $docente->correo_personal) : old('correo_personal')); ?>"
                                autocomplete="correo_personal" autofocus>
                            <?php $__errorArgs = ['correo_personal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="dedicacion"><?php echo e(__('Dedicación *')); ?></label>
                            <select class="form-control" name="dedicacion" id="dedicacion">
                                <option value="medio-tiempo"
                                    <?php echo e($cuenta > 0 ? ($docente->dedicacion == 'medio-tiempo' ? 'selected' : '') : ''); ?>>Medio tiempo
                                </option>
                                <option value="tiemplo-completo"
                                    <?php echo e($cuenta > 0 ? ($docente->dedicacion == 'tiemplo-completo' ? 'selected' : '') : ''); ?>>Tiempo completo
                                </option>
                                <option value="tiempo-catedra"
                                    <?php echo e($cuenta > 0 ? ($docente->dedicacion == 'tiempo-catedra' ? 'selected' : '') : ''); ?>>Tiempo catedra
                                </option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="tipo_contratacion"><?php echo e(__('Tipo de contratación *')); ?></label>
                            <select class="form-control" name="tipo_contratacion" id="tipo_contratacion">
                                <option value="contrato-indefinido" <?php echo e($cuenta > 0 ? ($docente->tipo_contratacion == 'contrato-indefinido' ? 'selected' : '') : ''); ?>>Contrato indefinido</option>
                                <option value="contrato-a-termino-fijo" <?php echo e($cuenta > 0 ? ($docente->tipo_contratacion == 'contrato-a-termino-fijo' ? 'selected' : '') : ''); ?>> Contrato a término fijo</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="fecha_vinculacion"><?php echo e(__('Fecha vinculación *')); ?></label>
                            <input id="fecha_vinculacion" type="date"
                                class="form-control <?php $__errorArgs = ['fecha_vinculacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="fecha_vinculacion"
                                value="<?php echo e($cuenta > 0 ? ($docente->fecha_vinculacion == "" ? old('fecha_vinculacion') : $docente->fecha_vinculacion) : old('fecha_vinculacion')); ?>"
                                autocomplete="fecha_vinculacion" autofocus>
                            <?php $__errorArgs = ['fecha_vinculacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="eps"><?php echo e(__('EPS afiliado *')); ?></label>
                            <input id="eps" type="text" class="form-control <?php $__errorArgs = ['eps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="eps" value="<?php echo e($cuenta > 0 ? ($docente->eps == "" ? old('eps') : $docente->eps) : old('eps')); ?>"
                                autocomplete="eps" autofocus>
                            <?php $__errorArgs = ['eps'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="riesgo"><?php echo e(__('Riesgo *')); ?></label>
                            <input id="riesgo" type="text" class="form-control <?php $__errorArgs = ['riesgo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="riesgo" value="<?php echo e($cuenta > 0 ? ($docente->riesgo == "" ? old('riesgo') : $docente->riesgo) : old('riesgo')); ?>"
                                autocomplete="riesgo" autofocus>
                            <?php $__errorArgs = ['riesgo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="cajacompensacion"><?php echo e(__('Caja de compensación *')); ?></label>
                            <input id="cajacompensacion" type="text"
                                class="form-control <?php $__errorArgs = ['cajacompensacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="cajacompensacion"
                                value="<?php echo e($cuenta > 0 ? ($docente->caja_compensacion == "" ? old('cajacompensacion') : $docente->caja_compensacion) : old('cajacompensacion')); ?>"
                                autocomplete="cajacompensacion" autofocus>
                            <?php $__errorArgs = ['cajacompensacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="banco"><?php echo e(__('Banco *')); ?></label>
                            <input id="banco" type="text" class="form-control <?php $__errorArgs = ['banco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="banco" value="<?php echo e($cuenta > 0 ? ($docente->banco == "" ? old('banco') : $docente->banco) : old('banco')); ?>"
                                autocomplete="banco" autofocus>
                            <?php $__errorArgs = ['banco'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="no_cuenta"><?php echo e(__('Número de cuenta *')); ?></label>
                            <input id="no_cuenta" type="text"
                                class="form-control <?php $__errorArgs = ['no_cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="no_cuenta"
                                value="<?php echo e($cuenta > 0 ? ($docente->no_cuenta == "" ? old('no_cuenta') : $docente->no_cuenta) : old('no_cuenta')); ?>"
                                autocomplete="no_cuenta" autofocus>
                            <?php $__errorArgs = ['no_cuenta'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="pension"><?php echo e(__('Pension *')); ?></label>
                            <input id="pension" type="text" class="form-control <?php $__errorArgs = ['pension'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="pension"
                                value="<?php echo e($cuenta > 0 ? ($docente->pension == "" ? old('pension') : $docente->pension) : old('pension')); ?>"
                                autocomplete="pension" autofocus>
                            <?php $__errorArgs = ['pension'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="estado"><?php echo e(__('Estado *')); ?></label>
                            <select class="form-control" name="estado" id="estado">
                                <option value="activo" <?php echo e($cuenta > 0 ? ($docente->estado == 'activo' ? 'selected' : '') : ''); ?>>Activo
                                </option>
                                <option value="inactivo" <?php echo e($cuenta > 0 ? ($docente->estado == 'inactivo' ? 'selected' : '') : ''); ?>>
                                    Inactivo</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mb-0">
                        <div class="col-md-12 offset-md-12">
                            <button type="submit" class="btn btn-success">
                                <?php echo e(__('Siguiente')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="tab-pane fade <?php echo e($cuenta > 0 ? ($docente->id_proceso == 2 ? 'show active' : '') : 'show active'); ?> tile p-3" id="estudio" role="tabpanel" aria-labelledby="estudio-tab">
                <form action="/docente/<?php echo e($persona->id); ?>/directorestudios" method="post"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <input type="hidden" value="<?php echo e($persona->id); ?>" name="id" id="id" readonly>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label
                                for="institucion_esp"><?php echo e(__('Nombre de la institución donde realizo especialización (Opcional)')); ?></label>
                            <input id="institucion_esp" type="text"
                                class="form-control <?php $__errorArgs = ['institucion_esp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="institucion_esp" value="<?php echo e($cuenta > 0 ? ($docente->institucion_esp == "" ? old('institucion_esp') : $docente->institucion_esp) : old('institucion_esp')); ?>"
                                autocomplete="institucion_esp" autofocus>
                            <?php $__errorArgs = ['institucion_esp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="certificado_esp"><?php echo e(__('Certificado especialización (Opcional)')); ?></label>
                            <input id="certificado_esp" type="file"
                                class="form-control <?php $__errorArgs = ['certificado_esp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="certificado_esp" value="<?php echo e(old('certificado_esp')); ?>"
                                autocomplete="certificado_esp" autofocus>
                            <?php $__errorArgs = ['certificado_esp'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <a target="_blank" href="<?php echo e($cuenta > 0 ? ($docente->certificado_esp == "" ? '' : asset('estudios/'.$docente->certificado_esp) ) : asset('estudios/'.$docente->certificado_esp)); ?>">ver. <?php echo e($docente->certificado_esp); ?></a>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label
                                for="institucion_dip"><?php echo e(__('Nombre de la institución donde realizo diplomado (Opcional)')); ?></label>
                            <input id="institucion_dip" type="text"
                                class="form-control <?php $__errorArgs = ['institucion_dip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="institucion_dip" value="<?php echo e($cuenta > 0 ? ($docente->institucion_dip == "" ? old('institucion_dip') : $docente->institucion_dip) : old('institucion_dip')); ?>"
                                autocomplete="institucion_dip" autofocus>
                            <?php $__errorArgs = ['institucion_dip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="certificado_dip"><?php echo e(__('Certificado diplomado (Opcional)')); ?></label>
                            <input id="certificado_dip" type="file"
                                class="form-control <?php $__errorArgs = ['certificado_dip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="certificado_dip" value="<?php echo e(old('certificado_dip')); ?>"
                                autocomplete="certificado_dip" autofocus>
                            <?php $__errorArgs = ['certificado_dip'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <a target="_blank" href="<?php echo e($cuenta > 0 ? ($docente->certificado_dip == "" ? '' : asset('estudios/'.$docente->certificado_dip) ) : asset('estudios/'.$docente->certificado_dip)); ?>">ver. <?php echo e($docente->certificado_dip); ?></a>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="titulo_pregrado"><?php echo e(__('Titulo pregrado (Opcional)')); ?></label>
                            <input id="titulo_pregrado" type="text"
                                class="form-control <?php $__errorArgs = ['titulo_pregrado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="titulo_pregrado" value="<?php echo e($cuenta > 0 ? ($docente->titulo_pregrado == "" ? old('titulo_pregrado') : $docente->titulo_pregrado) : old('titulo_pregrado')); ?>"
                                autocomplete="titulo_pregrado" autofocus>
                            <?php $__errorArgs = ['titulo_pregrado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label
                                for="institucion_pre"><?php echo e(__('Nombre de la institución donde realizo pregrado (Opcional)')); ?></label>
                            <input id="institucion_pre" type="text"
                                class="form-control <?php $__errorArgs = ['institucion_pre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="institucion_pre" value="<?php echo e($docente->institucion_pre); ?>"
                                autocomplete="institucion_pre" autofocus>
                            <?php $__errorArgs = ['institucion_pre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label
                                for="titulo_especializacion"><?php echo e(__('Titulo de especialización (Opcional)')); ?></label>
                            <input id="titulo_especializacion" type="text"
                                class="form-control <?php $__errorArgs = ['titulo_especializacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="titulo_especializacion" value="<?php echo e($cuenta > 0 ? ($docente->titulo_especializacion == "" ? old('titulo_especializacion') : $docente->titulo_especializacion) : old('titulo_especializacion')); ?>"
                                autocomplete="titulo_especializacion" autofocus>
                            <?php $__errorArgs = ['titulo_especializacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label
                                for="institucion_espe"><?php echo e(__('Nombre de la institución donde realizo especialización (Opcional)')); ?></label>
                            <input id="institucion_espe" type="text"
                                class="form-control <?php $__errorArgs = ['institucion_espe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="institucion_espe" value="<?php echo e(old('institucion_espe')); ?>"
                                autocomplete="institucion_espe" autofocus>
                            <?php $__errorArgs = ['institucion_espe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <a target="_blank" href="<?php echo e($cuenta > 0 ? ($docente->institucion_espe == "" ? '' : asset('estudios/'.$docente->institucion_espe) ) : asset('estudios/'.$docente->institucion_espe)); ?>">ver. <?php echo e($docente->institucion_espe); ?></a>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="titulo_maestria"><?php echo e(__('Titulo de maestria (Opcional)')); ?></label>
                            <input id="titulo_maestria" type="text"
                                class="form-control <?php $__errorArgs = ['titulo_maestria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="titulo_maestria" value="<?php echo e($cuenta > 0 ? ($docente->titulo_maestria == "" ? old('titulo_maestria') : $docente->titulo_maestria) : old('titulo_maestria')); ?>"
                                autocomplete="titulo_maestria" autofocus>
                            <?php $__errorArgs = ['titulo_maestria'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label
                                for="institucion_mae"><?php echo e(__('Nombre de la institución donde realizo maestria (Opcional)')); ?></label>
                            <input id="institucion_mae" type="text"
                                class="form-control <?php $__errorArgs = ['institucion_mae'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="institucion_mae" value="<?php echo e(old('institucion_mae')); ?>"
                                autocomplete="institucion_mae" autofocus>
                            <?php $__errorArgs = ['institucion_mae'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="titulo_doctorado"><?php echo e(__('Titulo doctorado (Opcional)')); ?></label>
                            <input id="titulo_doctorado" type="text"
                                class="form-control <?php $__errorArgs = ['titulo_doctorado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="titulo_doctorado" value="<?php echo e($cuenta > 0 ? ($docente->titulo_doctorado == "" ? old('titulo_doctorado') : $docente->titulo_doctorado) : old('titulo_doctorado')); ?>"
                                autocomplete="titulo_doctorado" autofocus>
                            <?php $__errorArgs = ['titulo_doctorado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label
                                for="institucion_doc"><?php echo e(__('Nombre de la institución donde realizo doctorado (Opcional)')); ?></label>
                            <input id="institucion_doc" type="text"
                                class="form-control <?php $__errorArgs = ['institucion_doc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="institucion_doc" value="<?php echo e($cuenta > 0 ? ($docente->institucion_doc == "" ? old('institucion_doc') : $docente->institucion_doc) : old('institucion_doc')); ?>"
                                autocomplete="institucion_doc" autofocus>
                            <?php $__errorArgs = ['institucion_doc'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="area_conocimiento"><?php echo e(__('Area de conocimiento *')); ?></label>
                            <input id="area_conocimiento" type="text"
                                class="form-control <?php $__errorArgs = ['area_conocimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="area_conocimiento" value="<?php echo e($cuenta > 0 ? ($docente->area_conocimiento == "" ? old('area_conocimiento') : $docente->area_conocimiento) : old('area_conocimiento')); ?>"
                                autocomplete="area_conocimiento" autofocus>
                            <?php $__errorArgs = ['area_conocimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="maximo_nivel_formacion"><?php echo e(__('Máximo nivel de formación *')); ?></label>
                            <input id="maximo_nivel_formacion" type="text"
                                class="form-control <?php $__errorArgs = ['maximo_nivel_formacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="maximo_nivel_formacion" value="<?php echo e($cuenta > 0 ? ($docente->maximo_nivel_formacion == "" ? old('maximo_nivel_formacion') : $docente->maximo_nivel_formacion) : old('maximo_nivel_formacion')); ?>"
                                autocomplete="maximo_nivel_formacion" autofocus>
                            <?php $__errorArgs = ['maximo_nivel_formacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="titulo_maximo_nivel"><?php echo e(__('Titulo máximo nivel *')); ?></label>
                            <input id="titulo_maximo_nivel" type="text"
                                class="form-control <?php $__errorArgs = ['titulo_maximo_nivel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="titulo_maximo_nivel" value="<?php echo e($cuenta > 0 ? ($docente->titulo_maximo_nivel == "" ? old('titulo_maximo_nivel') : $docente->titulo_maximo_nivel) : old('titulo_maximo_nivel')); ?>"
                                autocomplete="titulo_maximo_nivel" autofocus>
                            <?php $__errorArgs = ['titulo_maximo_nivel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label
                                for="institucion_maximo_nivel"><?php echo e(__('Nombre Institución máximo nivel *')); ?></label>
                            <input id="institucion_maximo_nivel" type="text"
                                class="form-control <?php $__errorArgs = ['institucion_maximo_nivel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="institucion_maximo_nivel" value="<?php echo e($cuenta > 0 ? ($docente->institucion_maximo_nivel == "" ? old('institucion_maximo_nivel') : $docente->institucion_maximo_nivel) : old('institucion_maximo_nivel')); ?>"
                                autocomplete="institucion_maximo_nivel" autofocus>
                            <?php $__errorArgs = ['institucion_maximo_nivel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="modalidad_programa"><?php echo e(__('Modalidad programa *')); ?></label>
                            <select class="form-control" name="modalidad_programa" id="modalidad_programa">
                                <option value="">---- SELECCIONE ----</option>
                                <option value="presencial" <?php echo e($cuenta > 0 ? ($docente->modalidad_programa == 'presencial' ? 'selected' : '') : 'presencial'); ?>>Presencial</option>
                                <option value="virtual" <?php echo e($cuenta > 0 ? ($docente->modalidad_programa == 'virtual' ? 'selected' : '') : 'virtual'); ?>>Virtual</option>
                            </select>
                        </div>
                        <div class="col-md-6">
                            <label for="soporte_hoja_vida"><?php echo e(__('Cargar soporte hoja de vida *')); ?></label>
                            <input id="soporte_hoja_vida" type="file"
                                class="form-control <?php $__errorArgs = ['soporte_hoja_vida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="soporte_hoja_vida" value="<?php echo e(old('soporte_hoja_vida')); ?>"
                                autocomplete="soporte_hoja_vida" autofocus>
                            <?php $__errorArgs = ['soporte_hoja_vida'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            <a target="_blank" href="<?php echo e($cuenta > 0 ? ($docente->soporte_hoja_vida == "" ? '' : asset('estudios/'.$docente->soporte_hoja_vida) ) : asset('estudios/'.$docente->soporte_hoja_vida)); ?>">ver. <?php echo e($docente->soporte_hoja_vida); ?></a>
                        </div>
                    </div>
                    <div class="row mb-0">
                        <div class="col-md-12 offset-md-12">
                            <button type="submit" class="btn btn-success">
                                <?php echo e(__('Siguiente')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
            <div class="tab-pane fade <?php echo e($cuenta > 0 ? ($docente->id_proceso == 3 ? 'show active' : '') : 'show active'); ?> tile p-3" id="zip" role="tabpanel" aria-labelledby="zip-tab">
                <form action="/docente/<?php echo e($persona->id); ?>/zip" method="post"
                    enctype="multipart/form-data">
                    <?php echo csrf_field(); ?> <?php echo method_field('PUT'); ?>
                    <input type="hidden" value="<?php echo e($persona->id); ?>" name="id" id="id" readonly>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label
                                for="documentos_compl"><?php echo e(__('Cargar archivo comprimido .zip (Documento de identidad, RUT etc..)')); ?></label>
                            <input id="documentos_compl" type="file"
                                class="form-control <?php $__errorArgs = ['documentos_compl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="documentos_compl" value="<?php echo e($cuenta > 0 ? ($docente->documentos_compl == "" ? old('documentos_compl') : $docente->documentos_compl) : old('documentos_compl')); ?>"
                                autocomplete="documentos_compl" autofocus>
                            <?php $__errorArgs = ['documentos_compl'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-12 offset-md-12 mt-2">
                            <button type="submit" class="btn btn-success">
                                <?php echo e(__('Finalizar')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/docente/created.blade.php ENDPATH**/ ?>