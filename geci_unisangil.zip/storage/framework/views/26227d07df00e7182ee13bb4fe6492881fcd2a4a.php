<?php if(Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    <!doctype html>
    <html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- CSRF Token -->
        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">

        <link rel="shortcut icon" href="<?php echo e(asset('image/favicon.png')); ?>" type="image/x-icon">
        <title><?php echo e('GICPAC | Ingreso al sistema'); ?></title>

        <!-- Scripts -->
        <script src="<?php echo e(asset('js/app.js')); ?>" defer></script>

        <!-- Fonts -->
        <link rel="dns-prefetch" href="//fonts.gstatic.com">
        <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">

        <!-- Styles -->
        <link rel="stylesheet" href="<?php echo e(asset('css/main.css')); ?>">
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">

        <!--DataTables -->
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.11.3/css/jquery.dataTables.css">

        <!--Select2-->
        <link href="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/css/select2.min.css" rel="stylesheet" />

        <link rel="stylesheet" type="text/css"
            href="https://maxcdn.bootstrapcdn.com/font-awesome/4.7.0/css/font-awesome.min.css">
    </head>

    <style>
        body{
            background-color: #f2f3f8;
        }
        .card-login{
            width: 400px;
            margin: auto;
            margin-top: 15%;
        }
        .footer {
            text-align: center;
            width: 100%;
            bottom: 10px;
            position: fixed;
        }
    </style>

    <body>
        <div class="container">
            <div class="row mx-auto">
                <div class="card-login tile">
                    <form method="POST" action="<?php echo e(route('login')); ?>">
                        <?php echo csrf_field(); ?>
                        <div class="d-flex justify-content-center">
                            <a class="navbar-brand" href="/home"><img src="<?php echo e(asset('image/logo.jpg')); ?>" width="300px"></a>
                        </div>
                        <div class="row mb-3">
                            <label for="per_correo"
                                class="col-md-12 col-form-label text-md-left"><?php echo e(__('Correo electronico *')); ?></label>
                            <div class="col-md-12">
                                <input id="per_correo" type="email"
                                    class="form-control <?php $__errorArgs = ['per_correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="per_correo"
                                    value="<?php echo e(old('per_correo')); ?>" autocomplete="per_correo" autofocus>
                                <?php $__errorArgs = ['per_correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-3">
                            <label for="password"
                                class="col-md-12 col-form-label text-md-left"><?php echo e(__('Contraseña *')); ?></label>
                            <div class="col-md-12">
                                <input id="password" type="password"
                                    class="form-control <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="password"
                                    autocomplete="current-password">
                                <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                        </div>
                        <div class="row mb-0">
                            <div class="col-md-12 offset-md-12">
                                <button type="submit" class="btn btn-success w-100">
                                    <?php echo e(__('Iniciar sesión')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                    <br>
                    <div class="d-flex justify-content-end">
                        <a href="/usuario/create">Registrarse</a>
                    </div>
                </div>
            </div>
        </div>
        <p class="text-center footer">Copyright &copy 2022. Todos los derechos reservados</p>

    </body>

    </html>
<?php endif; ?>
<?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/auth/login.blade.php ENDPATH**/ ?>