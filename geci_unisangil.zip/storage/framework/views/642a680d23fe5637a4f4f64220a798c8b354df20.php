
<?php $__env->startSection('title_report'); ?><p>PRUEBA SABER</p><?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<img src="<?php echo e(public_path('image/logo.jpg')); ?>">
<p class="header_right">UNISANGIL <br><?php
    $fecha = date('Y-m-d');
    echo 'FECHA: '.$fecha;
?> <br>MÓDULO: PRUEBAS SABER 11</p>
<table class="table">
    <thead>
        <tr>
            <th>ID</th>
            <th>Año presentación</th>
            <th>Periodo</th>
            <th>Nombre (s)</th>
            <th>Apellido (s)</th>
            <th>Puntaje global</th>
        </tr>
    </thead>
    <tbody>
        <?php $i = 1; ?>
        <?php $__currentLoopData = $datos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prueba): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($i++); ?></td>
                <td><?php echo e($prueba->prueba_saber_year); ?></td>
                <td><?php echo e($prueba->prueba_saber_periodo); ?></td>
                <td><?php echo e($prueba->per_nombre); ?></td>
                <td><?php echo e($prueba->per_apellido); ?></td>
                <td><?php echo e(number_format($prueba->prueba_saber_puntaje_global,2)); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('reporte.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/reporte/pruebasaber11.blade.php ENDPATH**/ ?>