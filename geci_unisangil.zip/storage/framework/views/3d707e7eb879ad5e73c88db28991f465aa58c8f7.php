<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-table"></i> Módulo Estudiantes</h1>
    <?php $__env->startSection('message'); ?>
        <p>Lista de registro estudiantes</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="tile col-md-12 mt-2 p-4">
            <div class="row">
                <div class="col-md-8">
                    <h4>Listado estudiantes</h4>
                </div>
                <div class="col-md-4 d-flex justify-content-end">
                    <a class="btn btn-outline-danger" style="border-radius: 100%"
                        href="<?php echo e(url('estudiante/' . $programax . '/exportpdf')); ?>" title="Generar reporte pdf"
                        target="_blank"><i class="fa fa-file-pdf-o"></i></a>
                    <div class="dropdown">
                        <a class="btn btn-outline-success" style="border-radius: 100%" href="#" role="button"
                            id="dropdownMenuLink" data-toggle="dropdown" aria-expanded="false">
                            <i class="fa fa-file-excel-o"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <a class="dropdown-item"
                                href="<?php echo e(url('estudiante/' . $programax . '/exportexcel')); ?>">Listado general
                                programa</a>
                            <a class="dropdown-item"
                                href="<?php echo e(url('estudiante/' . $programax . '/exportbecaexcel')); ?>">Listado SF Beca</a>
                            <a class="dropdown-item"
                                href="<?php echo e(url('estudiante/' . $programax . '/exportcontadoexcel')); ?>">Listado SF De
                                contado</a>
                            <a class="dropdown-item"
                                href="<?php echo e(url('estudiante/' . $programax . '/exportprestamoexcel')); ?>">Listado SF
                                Prestamo</a>
                        </div>
                    </div>
                    <a class="btn btn-outline-success " href="<?php echo e(url('estudiante/create')); ?>"><i
                            class="fa fa-plus-circle"></i>
                        Nuevo</a>
                </div>
            </div>
            <br>
            <div class="table-responsive">
                <table class="table" id="tables">
                    <thead>
                        <tr>
                            <th>N°</th>
                            <th>Tipo Documento</th>
                            <th>Número Documento</th>
                            <th>Nombre(s)</th>
                            <th>Apellido (s)</th>
                            <th>Correo electronico</th>
                            <th>Año de ingreso</th>
                            <th>¿Egresado?</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $programaestudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($persona->per_tipo_documento); ?></td>
                                <td><?php echo e($persona->per_numero_documento); ?></td>
                                <td><?php echo e($persona->per_nombre); ?></td>
                                <td><?php echo e($persona->per_apellido); ?></td>
                                <td><?php echo e($persona->per_correo); ?></td>
                                <td><?php echo e($persona->estu_ingreso); ?></td>
                                <td><?php echo e($persona->estu_egresado); ?> <a class="badge badge-info"
                                        href="/estudiante/<?php echo e($persona->id); ?>/crearegresado"><?php echo e($persona->estu_egresado == 'Si' ? 'Completar datos egresado' : ''); ?></a>
                                </td>
                                <?php if(Auth::user()->per_tipo_usuario == 1 || Auth::user()->per_tipo_usuario == 2): ?>
                                    <td style="width: 10%">
                                        <form action="<?php echo e(route('estudiante.destroy', $persona->id)); ?>" method="POST">
                                            <div class="d-flex">
                                                <a class="btn btn-sm" href="/estudiante/<?php echo e($persona->id); ?>"><i
                                                        class="fa fa-folder-open "></i></a>
                                                <a class="btn btn-outline-info btn-sm"
                                                    href="/estudiante/<?php echo e($persona->id); ?>/edit"><i
                                                        class="fa fa-refresh"></i></a>
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('DELETE'); ?>
                                                <button type="submit" class="btn btn-danger btn-sm btn-eye"><i
                                                        class="fa fa-trash"></i></button>
                                            </div>
                                        </form>
                                    </td>
                                <?php endif; ?>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <hr>
        <div class="row">
            <div class="mt-3 tile" style="width: 600px; margin-left: 15px;">
                <h4><i class="fa fa-files-o"></i> Reporte por año de ingreso</h4><hr>
                <form action="/estudiante/<?php echo e($programax); ?>/listadoingreso" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label>Listado por año de ingreso: </label>
                            <select class="form-control <?php $__errorArgs = ['estu_ingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_ingreso"
                                id="estu_ingreso">
                                <option value="">---- SELECCIONE ----</option>
                                <?php $__currentLoopData = $ingresos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ingreso): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($ingreso->estu_ingreso); ?>"><?php echo e($ingreso->estu_ingreso); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['estu_ingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-12 mt-3">
                            <button type="submit" class="btn btn-success mb-2">Generar reporte</button>
                        </div>
                    </div>
                </form>
            </div>
            <div class=" mt-3 tile" style="width: 600px; margin-left: 15px;">
                <h4><i class="fa fa-files-o"></i> Reporte por periodo académico</h4>
                <hr>
                <form action="/estudiante/<?php echo e($programax); ?>/listadoperiodoingreso" method="post">
                    <?php echo csrf_field(); ?>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <label>Listado por periodo académico: </label>
                            <select class="form-control <?php $__errorArgs = ['estu_periodo_ingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="estu_periodo_ingreso" id="estu_periodo_ingreso">
                                <option value="">---- SELECCIONE ----</option>
                                <?php $__currentLoopData = $periodos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $periodo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($periodo->estu_periodo_ingreso); ?>">
                                        <?php echo e($periodo->estu_periodo_ingreso); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ['estu_periodo_ingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-12">
                            <button type="submit" class="btn btn-success mb-2">Generar reporte</button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/estudiante/listado.blade.php ENDPATH**/ ?>