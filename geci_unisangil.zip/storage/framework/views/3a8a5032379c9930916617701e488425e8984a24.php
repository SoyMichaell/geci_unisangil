<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/extension/<?php echo e($nacional->id); ?>/editarmovilidadnacional">Editar</a> / <a href="/extension/mostrarmovilidadnacional">Movilidad nacional</a> / <a href="/extension">Extension - internacionalización</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-pencil-square-o"></i> Formulario de edición</h1>
    <?php $__env->startSection('message'); ?>
        <p>Diligenciar todos los campos requeridos.</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="tile">
            <h4><i class="fa fa-pencil"></i> Actualizar información</h4><hr>
            <form action="/extension/<?php echo e($nacional->id); ?>/actualizarmovilidadnacional" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="exmona_tipo">Tipo</label>
                        <select class="form-control <?php $__errorArgs = ['exmona_tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="exmona_tipo"
                            id="exmona_tipo">
                            <option value="">---- SELECCIONE ----</option>
                            <option value="entrante" <?php echo e($nacional->exmona_tipo == 'entrante' ? 'selected' : ''); ?>>Entrante</option>
                            <option value="saliente" <?php echo e($nacional->exmona_tipo == 'saliente' ? 'selected' : ''); ?>>Saliente</option>
                        </select>
                        <?php $__errorArgs = ['exmona_tipo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="exmona_rol">Rol</label>
                        <select class="form-control <?php $__errorArgs = ['exmona_rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="exmona_rol"
                            id="exmona_rol">
                            <option value="">---- SELECCIONE ----</option>
                            <option value="estudiante" <?php echo e($nacional->exmona_rol == 'estudiante' ? 'selected' : ''); ?>>Estudiante</option>
                            <option value="docente" <?php echo e($nacional->exmona_rol == 'docente' ? 'selected' : ''); ?>>Docente</option>
                            <option value="administrativo" <?php echo e($nacional->exmona_rol == 'administrativo' ? 'selected' : ''); ?>>Administrativo</option>
                        </select>
                        <?php $__errorArgs = ['exmona_rol'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="exmona_id_sede">Sede</label>
                        <select class="form-control <?php $__errorArgs = ['exmona_id_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="exmona_id_sede" id="exmona_id_sede">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $sedes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $sede): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($sede->id); ?>" <?php echo e($sede->id == $nacional->exmona_id_sede ? 'selected' : ''); ?>><?php echo e($sede->mun_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['exmona_id_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="exmona_id_facultad">Facultad</label>
                        <select class="form-control <?php $__errorArgs = ['exmona_id_facultad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="exmona_id_facultad" id="exmona_id_facultad">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $facultades; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $facultad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($facultad->id); ?>" <?php echo e($facultad->id == $nacional->exmona_id_facultad ? 'selected' : ''); ?>><?php echo e($facultad->fac_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['exmona_id_facultad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="exmona_id_programa">Programa</label>
                        <select class="form-control <?php $__errorArgs = ['exmona_id_programa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="exmona_id_programa" id="exmona_id_programa">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($programa->id); ?>" <?php echo e($programa->id == $nacional->exmona_id_programa ? 'selected' : ''); ?>><?php echo e($programa->pro_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['exmona_id_programa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 otros" id="otros">
                        <label for="exmona_id_persona">Persona - Nombre completo</label>
                        <select class="js-example-placeholder-single form-control <?php $__errorArgs = ['exmona_id_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="exmona_id_persona" id="exmona_id_persona">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $personas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $persona): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($persona->id); ?>" <?php echo e($persona->id == $nacional->exmona_id_persona ? 'selected' : ''); ?>>
                                    <?php echo e($persona->per_nombre . ' ' . $persona->per_apellido); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['exmona_id_persona'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6 estudiantes" id="estudiantes">
                        <label for="exmona_id_estudiante">Persona - Nombre completo</label>
                        <select class="js-example-placeholder-single form-control <?php $__errorArgs = ['exmona_id_estudiante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="exmona_id_estudiante" id="exmona_id_estudiante">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $estudiantes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $estudiante): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($estudiante->id); ?>" <?php echo e($estudiante->id == $nacional->exmona_id_persona ? 'selected' : ''); ?>>
                                    <?php echo e($estudiante->per_nombre . ' ' . $estudiante->per_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        
                        <?php echo e($estudiantes->count()<=0 ? 'No hay estudiantes en plataforma' : ''); ?>

                        <?php $__errorArgs = ['exmona_id_estudiante'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="exmona_institucion_proviene">Institución educativa, organización o entidad de donde
                            proviene la movilidad. Por favor indique el nombre completo, sin siglas.</label>
                        <input class="form-control <?php $__errorArgs = ['exmona_institucion_proviene'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="exmona_institucion_proviene" id="exmona_institucion_proviene"
                            value="<?php echo e($nacional->exmona_institucion_proviene); ?>" type="text"
                            autocomplete="exmona_institucion_proviene" autofocus>
                        <?php $__errorArgs = ['exmona_institucion_proviene'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="exmona_tipo_movilidad">Tipo de movilidad</label>
                        <?php
                            $tipom = explode(';', $nacional->exmona_tipo_movilidad);
                        ?>
                        <div class="form-check">
                            <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                value="Misión" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Misión' ? 'checked' : ''); ?> <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                            <label class="form-check-label" for="flexCheckChecked">
                                Misión
                            </label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                value="Curso corto" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Curso corto' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                            <label class="form-check-label" for="flexCheckChecked">
                                Curso corto
                            </label>
                        </div>
                        <div class="tipo-estudiante" id="tipo-estudiante">
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Voluntariado" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Voluntariado' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Voluntariado
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Pasantia" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Pasantia' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Pasantía
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Pasantia o práctica" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Pasantia o práctica' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Pasantía o práctica
                                </label>
                            </div>
                            
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Asistencia a eventos" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Asistencia a eventos' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Asistencia a eventos
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Curso de idiomas" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Curso de idiomas' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Curso de idiomas
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Semestre acádemico de intercambio" id="flexCheckChecked">
                                <label class="form-check-label" for="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Semestre acádemico de intercambio' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                    Semestre acádemico de intercambio
                                </label>
                            </div>
                        </div>
                        <div class="entrante-docente" id="entrante-docente">
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Estancia de investigación" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Estancia de investigación' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Estancia de investigación
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Profesor programa pregrado" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Profesor programa pregrado' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Profesor programa pregrado
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Profesor programa especialización" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Profesor programa especialización' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Profesor programa especialización
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Profesor programa maestría" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Profesor programa maestría' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Profesor programa maestría
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Profesor programa doctorado" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Profesor programa doctorado' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Profesor programa doctorado
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Profesor programa posdoctorado" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Profesor programa posdoctorado' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Profesor programa posdoctorado
                                </label>
                            </div>
                        </div>
                        <div class="saliente-docente" id="saliente-docente">
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Estudios de maestría" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Estudios de maestría' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Estudios de maestría
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Estudios de doctorado" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Estudios de doctorado' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Estudios de doctorado
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Estudios de posdoctorado" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Estudios de posdoctorado' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Estudios de posdoctorado
                                </label>
                            </div>
                        </div>
                        <div class="entrante-administrativo" id="entrante-administrativo">
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Asistencia a eventos" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Asistencia a eventos' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Asistencia a eventos
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Pasantía" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Pasantía' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Pasantía
                                </label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" name="exmona_tipo_movilidad[]" type="checkbox"
                                    value="Gestión de convenios" id="flexCheckChecked" <?php $__currentLoopData = $tipom; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <?php echo e($m == 'Gestión de convenios' ? 'checked' : ''); ?>  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>>
                                <label class="form-check-label" for="flexCheckChecked">
                                    Gestión de convenios
                                </label>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-12">
                        <label for="exmona_descripcion">Descripción de la movilidad. Amplíe la información. Si se trata
                            de un evento académico por favor indique el nombre completo del evento, sin siglas.</label>
                        <textarea class="form-control <?php $__errorArgs = ['exmona_descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="exmona_descripcion" id="exmona_descripcion" cols="30" rows="10"><?php echo e($nacional->exmona_descripcion); ?></textarea>
                        <?php $__errorArgs = ['exmona_descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="exmona_fecha_inicio">Fecha de inicio</label>
                        <input class="form-control <?php $__errorArgs = ['exmona_fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="exmona_fecha_inicio" id="exmona_fecha_inicio"
                            value="<?php echo e($nacional->exmona_fecha_inicio); ?>" type="date"
                            autocomplete="exmona_fecha_inicio" autofocus>
                        <?php $__errorArgs = ['exmona_fecha_inicio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="exmona_fecha_final">Fecha final</label>
                        <input class="form-control <?php $__errorArgs = ['exmona_fecha_final'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="exmona_fecha_final" id="exmona_fecha_final"
                            value="<?php echo e($nacional->exmona_fecha_final); ?>" type="date"
                            autocomplete="exmona_fecha_final" autofocus>
                        <?php $__errorArgs = ['exmona_fecha_final'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-0">
                    <div class="col-md-12 offset-md-12">
                        <button type="submit" class="btn btn-success">
                            <?php echo e(__('Actualizar')); ?>

                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>
<?php $__env->startSection('scripts'); ?>
<script src="/js/admin/movilidad_nacional.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/extension/movilidades/nacional/edit.blade.php ENDPATH**/ ?>