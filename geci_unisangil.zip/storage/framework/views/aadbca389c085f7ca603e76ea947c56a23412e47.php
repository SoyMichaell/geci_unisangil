<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/programa/mostrarplan">Plan de estudio</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-table"></i> Plan de estudio</h1>
        <p>Listado plan de estudios programas</p>
    <?php $__env->startSection('message'); ?>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="table-responsive tile mt-2">
                    <div class="row mb-3">
                        <div class="col-md-7">
                            <h4>Listado plan de estudios</h4>
                        </div>
                        <div class="col-md-5 d-flex justify-content-end align-items-center">
                            <a class="btn btn-outline-success" href="/programa/crearplan"><i
                                    class="fa fa-plus-circle"></i>
                                Nuevo</a>
                        </div>
                    </div>
                    <table class="table" id="tables">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Sede</th>
                                <th>Programa</th>
                                <th>Plan de estudio</th>
                                <th>Número de creditos</th>
                                <th>Número de asignaturas</th>
                                <th>Estado</th>
                                <th style="width: 15%">Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($plan->id); ?></td>
                                    <td><?php echo e($plan->sedes->mun_nombre); ?></td>
                                    <td><?php echo e($plan->programas->pro_nombre); ?></td>
                                    <td><?php echo e($plan->pp_plan); ?></td>
                                    <td><?php echo e($plan->pp_creditos); ?></td>
                                    <td><?php echo e($plan->pp_no_asignaturas); ?></td>
                                    <td><?php echo e(Str::ucfirst($plan->pp_estado)); ?></td>
                                    <?php if(Auth::user()->per_tipo_usuario == 1 || Auth::user()->per_tipo_usuario == 2): ?>
                                        <td>
                                            <form action="/programa/<?php echo e($plan->id); ?>/estado" method="POST">
                                                <div class="d-flex text-center">
                                                    <?php if($plan->pp_estado == 'activo'): ?>
                                                        <a class="btn btn-outline-info btn-sm"
                                                            href="/programa/<?php echo e($plan->id); ?>/editarplan"><i
                                                                class="fa fa-refresh text-center"></i></a>
                                                    <?php endif; ?>
                                                    <?php echo csrf_field(); ?>
                                                    <?php echo method_field('PUT'); ?>
                                                    <?php if($plan->pp_estado == 'activo'): ?>
                                                        <button type="submit" class="btn btn-danger btn-sm"><i
                                                                class="fa fa-ban"></i> Inactivar</button>
                                                    <?php else: ?>
                                                        <button type="submit" class="btn btn-success btn-sm"><i
                                                                class="fa fa-circle-check"></i> Activar</button>
                                                    <?php endif; ?>
                                                </div>
                                            </form>
                                        </td>
                                    <?php endif; ?>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/programa/plan/index.blade.php ENDPATH**/ ?>