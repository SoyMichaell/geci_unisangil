<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-pencil-square-o"></i> Formulario de edición</h1>
    <?php $__env->startSection('message'); ?>
        <p>Diligenciar todos los campos requeridos *.</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="tile">
            <h4 class="title"><i class="fa fa-pencil"></i> Registro estudiante</h4>
            <hr>
            <form action="/estudiante/<?php echo e($persona->id); ?>" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_programa"><?php echo e(__('Programa *')); ?></label>
                        <select class="form-control" name="estu_programa" id="estu_programa">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($programa->id); ?>"
                                    <?php echo e($programa->id == $persona->estu_programa ? 'selected' : ''); ?>>
                                    <?php echo e($programa->pro_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['estu_programa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_programa_plan"><?php echo e(__('Plan de estudio *')); ?></label>
                        <select class="form-control" name="estu_programa_plan" id="estu_programa_plan">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $planes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($plan->id); ?>"
                                    <?php echo e($plan->id == $persona->estu_programa_plan ? 'selected' : ''); ?>>
                                    <?php echo e($plan->pp_plan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['estu_programa_plan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_tipo_documento"><?php echo e(__('Tipo Documento *')); ?></label>
                        <select class="form-control" name="estu_tipo_documento" id="estu_tipo_documento">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $tiposdocumento; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tipo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($tipo); ?>"
                                    <?php echo e($tipo == $persona->per_tipo_documento ? 'selected' : ''); ?>>
                                    <?php echo e($tipo); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['estu_tipo_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_numero_documento"><?php echo e(__('Número de Documento *')); ?></label>
                        <input id="estu_numero_documento" type="number"
                            class="form-control <?php $__errorArgs = ['estu_numero_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="estu_numero_documento" value="<?php echo e($persona->per_numero_documento); ?>"
                            autocomplete="estu_numero_documento" autofocus>
                        <?php $__errorArgs = ['estu_numero_documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_nombre"><?php echo e(__('Nombre (s) *')); ?></label>
                        <input id="estu_nombre" type="text"
                            class="form-control <?php $__errorArgs = ['estu_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_nombre"
                            value="<?php echo e($persona->per_nombre); ?>" autocomplete="estu_nombre" autofocus>
                        <?php $__errorArgs = ['estu_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_apellido"><?php echo e(__('Apellido (s) *')); ?></label>
                        <input id="estu_apellido" type="text"
                            class="form-control <?php $__errorArgs = ['estu_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_apellido"
                            value="<?php echo e($persona->per_apellido); ?>" autocomplete="estu_apellido" autofocus>
                        <?php $__errorArgs = ['estu_apellido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_telefono1"><?php echo e(__('Telefono 1 *')); ?></label>
                        <input id="estu_telefono1" type="number"
                            class="form-control <?php $__errorArgs = ['estu_telefono1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_telefono1"
                            value="<?php echo e($persona->per_telefono); ?>" autocomplete="estu_telefono1" autofocus>
                        <?php $__errorArgs = ['estu_telefono1'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_telefono2"><?php echo e(__('Telefono 2 (Opcional)')); ?></label>
                        <input id="estu_telefono2" type="number"
                            class="form-control <?php $__errorArgs = ['estu_telefono2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_telefono2"
                            value="<?php echo e($persona->estu_telefono2); ?>" autocomplete="estu_telefono2" autofocus>
                        <?php $__errorArgs = ['estu_telefono2'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_direccion"><?php echo e(__('Dirección (Opcional)')); ?></label>
                        <input id="estu_direccion" type="text"
                            class="form-control <?php $__errorArgs = ['estu_direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_direccion"
                            value="<?php echo e($persona->estu_direccion); ?>" autocomplete="estu_direccion" autofocus>
                        <?php $__errorArgs = ['estu_direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_correo"><?php echo e(__('Correo electronico institucional *')); ?></label>
                        <input id="estu_correo" type="email"
                            class="form-control <?php $__errorArgs = ['estu_correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_correo"
                            value="<?php echo e($persona->per_correo); ?>" autocomplete="estu_correo" autofocus>
                        <?php $__errorArgs = ['estu_correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_correo_personal"><?php echo e(__('Correo electronico personal (Opcional)')); ?></label>
                        <input id="estu_correo_personal" type="email"
                            class="form-control <?php $__errorArgs = ['estu_correo_personal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_correo_personal"
                            value="<?php echo e($persona->estu_correo_personal); ?>" autocomplete="estu_correo_personal" autofocus>
                        <?php $__errorArgs = ['estu_correo_personal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_colegio"><?php echo e(__('Institución educativa secundaría (Opcional)')); ?></label>
                        <input id="estu_colegio" type="text"
                            class="form-control <?php $__errorArgs = ['estu_colegio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_colegio"
                            value="<?php echo e($persona->estu_colegio); ?>" autocomplete="estu_colegio" autofocus>
                        <?php $__errorArgs = ['estu_colegio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_estrato"><?php echo e(__('Estrato (Opcional)')); ?></label>
                        <input id="estu_estrato" type="text"
                            class="form-control <?php $__errorArgs = ['estu_estrato'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_estrato"
                            value="<?php echo e($persona->estu_estrato); ?>" autocomplete="estu_estrato" autofocus>
                        <?php $__errorArgs = ['estu_estrato'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_departamento"><?php echo e(__('Departamento procendencia (Opcional)')); ?></label>
                        <select class="form-control" name="estu_departamento" id="estu_departamento">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $departamentos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $departamento): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($departamento->id); ?>"
                                    <?php echo e($departamento->id == $persona->per_departamento ? 'selected' : ''); ?>>
                                    <?php echo e($departamento->dep_nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['estu_departamento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_ciudad"><?php echo e(__('Municipio procendencia (Opcional)')); ?></label>
                        <select class="form-control" name="estu_ciudad" id="estu_ciudad">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($municipio->id); ?>"
                                    <?php echo e($municipio->id == $persona->per_ciudad ? 'selected' : ''); ?>>
                                    <?php echo e($municipio->mun_nombre); ?>

                                </option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['estu_ciudad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_fecha_nacimiento"><?php echo e(__('Fecha de Nacimiento (Opcional)')); ?></label>
                        <input id="estu_fecha_nacimiento" type="date"
                            class="form-control <?php $__errorArgs = ['estu_fecha_nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="estu_fecha_nacimiento" value="<?php echo e($persona->estu_fecha_nacimiento); ?>"
                            autocomplete="estu_fecha_nacimiento" autofocus>
                        <?php $__errorArgs = ['estu_fecha_nacimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_fecha_expedicion"><?php echo e(__('Fecha de Expedición  (Opcional)')); ?></label>
                        <input id="estu_fecha_expedicion" type="date"
                            class="form-control <?php $__errorArgs = ['estu_fecha_expedicion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="estu_fecha_expedicion" value="<?php echo e($persona->estu_fecha_expedicion); ?>"
                            autocomplete="estu_fecha_expedicion" autofocus>
                        <?php $__errorArgs = ['estu_fecha_expedicion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_sexo"><?php echo e(__('Sexo Biológico (Opcional)')); ?></label>
                        <select class="form-control" name="estu_sexo" id="estu_sexo">
                            <option value="">---- SELECCIONE ----</option>
                            <option value="M" <?php echo e($persona->estu_sexo == 'M' ? 'selected' : ''); ?>>Masculino</option>
                            <option value="F" <?php echo e($persona->estu_sexo == 'F' ? 'selected' : ''); ?>>Femenino</option>
                        </select>
                        <?php $__errorArgs = ['estu_sexo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_estado_civil"><?php echo e(__('Estado civil (Opcional)')); ?></label>
                        <select class="form-control" name="estu_estado_civil" id="estu_estado_civil">
                            <option value="">---- SELECCIONE ----</option>
                            <option value="soltero(a)"
                                <?php echo e($persona->estu_estado_civil == 'soltero(a)' ? 'selected' : ''); ?>>Soltero (a)
                            </option>
                            <option value="casado(a)" <?php echo e($persona->estu_estado_civil == 'F' ? 'casado(a)' : ''); ?>>
                                Casado (a)</option>
                            <option value="divorciado(a)"
                                <?php echo e($persona->estu_estado_civil == 'F' ? 'divorciado(a)' : ''); ?>>Divorciado (a)
                            </option>
                            <option value="viudo(a)" <?php echo e($persona->estu_estado_civil == 'F' ? 'viudo(a)' : ''); ?>>Viudo
                                (a)</option>
                            <option value="unionlibre" <?php echo e($persona->estu_estado_civil == 'F' ? 'unionlibre' : ''); ?>>
                                Unión libre</option>
                            <option value="religioso(a)"
                                <?php echo e($persona->estu_estado_civil == 'F' ? 'religioso(a)' : ''); ?>>Religioso (a)</option>
                            <option value="separado(a)"
                                <?php echo e($persona->estu_estado_civil == 'F' ? 'separado(a)' : ''); ?>>
                                Separado (a)</option>
                        </select>
                        <?php $__errorArgs = ['estu_estado_civil'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_ingreso"><?php echo e(__('Año de ingreso (Opcional)')); ?></label>
                        <input id="estu_ingreso" type="text"
                            class="form-control <?php $__errorArgs = ['estu_ingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_ingreso"
                            value="<?php echo e($persona->estu_ingreso); ?>" autocomplete="estu_ingreso" autofocus>
                        <?php $__errorArgs = ['estu_ingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_periodo_ingreso"><?php echo e(__('Periodo de ingreso (Opcional)')); ?></label>
                        <input id="estu_periodo_ingreso" type="text"
                            class="form-control <?php $__errorArgs = ['estu_periodo_ingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="estu_periodo_ingreso" value="<?php echo e($persona->estu_periodo_ingreso); ?>"
                            autocomplete="estu_periodo_ingreso" placeholder="Ej: 2016-1" autofocus>
                        <?php $__errorArgs = ['estu_periodo_ingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_ult_matricula"><?php echo e(__('Ultimo periodo matriculado (Opcional)')); ?></label>
                        <input id="estu_ult_matricula" type="text"
                            class="form-control <?php $__errorArgs = ['estu_ult_matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="estu_ult_matricula" value="<?php echo e($persona->estu_ult_matricula); ?>"
                            autocomplete="estu_ult_matricula" autofocus placeholder="Ej: 2022-1">
                        <?php $__errorArgs = ['estu_ult_matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_semestre"><?php echo e(__('Semestre *')); ?></label>
                        <select class="form-control" name="estu_semestre" id="estu_semestre">
                            <option value="">---- SELECCIONE ----</option>
                            <option value="1" <?php echo e($persona->estu_semestre == '1' ? 'selected' : ''); ?>>1</option>
                            <option value="2" <?php echo e($persona->estu_semestre == '2' ? 'selected' : ''); ?>>2</option>
                            <option value="3" <?php echo e($persona->estu_semestre == '3' ? 'selected' : ''); ?>>3</option>
                            <option value="4" <?php echo e($persona->estu_semestre == '4' ? 'selected' : ''); ?>>4</option>
                            <option value="5" <?php echo e($persona->estu_semestre == '5' ? 'selected' : ''); ?>>5</option>
                            <option value="6" <?php echo e($persona->estu_semestre == '6' ? 'selected' : ''); ?>>6</option>
                            <option value="7" <?php echo e($persona->estu_semestre == '7' ? 'selected' : ''); ?>>7</option>
                            <option value="8" <?php echo e($persona->estu_semestre == '8' ? 'selected' : ''); ?>>8</option>
                            <option value="9" <?php echo e($persona->estu_semestre == '9' ? 'selected' : ''); ?>>9</option>
                            <option value="10" <?php echo e($persona->estu_semestre == '10' ? 'selected' : ''); ?>>10</option>
                        </select>
                        <?php $__errorArgs = ['estu_semestre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_financiamiento"><?php echo e(__('Tipo de financiamiento (Opcional)')); ?></label>
                        <select class="form-control" name="estu_financiamiento" id="estu_financiamiento">
                            <option value="">---- SELECCIONE ----</option>
                            <option value="beca" <?php echo e($persona->estu_financiamiento == 'beca' ? 'selected' : ''); ?>>Beca
                            </option>
                            <option value="de-contado"
                                <?php echo e($persona->estu_financiamiento == 'de-contado' ? 'selected' : ''); ?>>De contado
                            </option>
                            <option value="prestamo"
                                <?php echo e($persona->estu_financiamiento == 'prestamo' ? 'selected' : ''); ?>>Prestamo</option>
                        </select>
                        <?php $__errorArgs = ['estu_financiamiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label
                            for="estu_entidad"><?php echo e(__('Tipo de Beca (Solo si el tipo de financiamiento es BECA)')); ?></label>
                        <input id="estu_entidad" type="text"
                            class="form-control <?php $__errorArgs = ['estu_entidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_entidad"
                            value="<?php echo e($persona->estu_entidad); ?>" autocomplete="estu_entidad" autofocus>
                        <?php $__errorArgs = ['estu_entidad'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_estado"><?php echo e(__('Estado *')); ?></label>
                        <select class="form-control" name="estu_estado" id="estu_estado">
                            <option value="">---- SELECCIONE ----</option>
                            <option value="activo" <?php echo e($persona->estu_estado == 'activo' ? 'selected' : ''); ?>>Activo
                            </option>
                            <option value="inactivo" <?php echo e($persona->estu_estado == 'inactivo' ? 'selected' : ''); ?>>
                                Inactivo</option>
                            <option value="reserva-cupo"
                                <?php echo e($persona->estu_estado == 'reserva-cupo' ? 'selected' : ''); ?>>Reserva de Cupo
                            </option>
                            <option value="pfu" <?php echo e($persona->estu_estado == 'pfu' ? 'selected' : ''); ?>>PFU</option>
                            <option value="bajo-rendimiento"
                                <?php echo e($persona->estu_estado == 'bajo-rendimiento' ? 'selected' : ''); ?>>Bajo Rendimiento
                            </option>
                            <option value="egresado" <?php echo e($persona->estu_estado == 'egresado' ? 'selected' : ''); ?>>
                                Egresado</option>
                            <option value="egresado-no-graduado"
                                <?php echo e($persona->estu_estado == 'egresado-no-graduado' ? 'selected' : ''); ?>>Egresado no
                                Graduado</option>
                        </select>
                        <?php $__errorArgs = ['estu_estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_tipo_matricula"><?php echo e(__('Tipo de matricula (Opcional)')); ?></label>
                        <select class="form-control" name="estu_tipo_matricula" id="estu_tipo_matricula">
                            <option value="">---- SELECCIONE ----</option>
                            <option value="movilidad-interna"
                                <?php echo e($persona->estu_tipo_matricula == 'movilidad-interna' ? 'selected' : ''); ?>>
                                Movilidad
                                Interna</option>
                            <option value="nuevo-transferencias-interna"
                                <?php echo e($persona->estu_tipo_matricula == 'nuevo-transferencias-interna' ? 'selected' : ''); ?>>
                                Nuevo Transferencias Interna</option>
                            <option value="nuevo-reingreso"
                                <?php echo e($persona->estu_tipo_matricula == 'nuevo-reingreso' ? 'selected' : ''); ?>>Nuevo
                                Reingreso</option>
                            <option value="estudiante-movilidad-academica"
                                <?php echo e($persona->estu_tipo_matricula == 'estudiante-movilidad-academica' ? 'selected' : ''); ?>>
                                Estudiante de Movilidad Académica</option>
                            <option value="movilidad-externa"
                                <?php echo e($persona->estu_tipo_matricula == 'movilidad-externa' ? 'selected' : ''); ?>>
                                Movilidad
                                Externa</option>
                            <option value="nuevo-transferencia-externa"
                                <?php echo e($persona->estu_tipo_matricula == 'nuevo-transferencia-externa' ? 'selected' : ''); ?>>
                                Nuevo Transferencia Externa</option>
                            <option value="antiguo"
                                <?php echo e($persona->estu_tipo_matricula == 'antiguo' ? 'selected' : ''); ?>>Antiguo</option>
                            <option value="transferencia-obligatoria"
                                <?php echo e($persona->estu_tipo_matricula == 'transferencia-obligatoria' ? 'selected' : ''); ?>>
                                Transferencia Obligatoria</option>
                            <option value="desertor"
                                <?php echo e($persona->estu_tipo_matricula == 'desertor' ? 'selected' : ''); ?>>Desertor
                            </option>
                            <option value="nuevo-regular"
                                <?php echo e($persona->estu_tipo_matricula == 'nuevo-regular' ? 'selected' : ''); ?>>Nuevo
                                Regular
                            </option>
                            <option value="continuidad-academica"
                                <?php echo e($persona->estu_tipo_matricula == 'continuidad-academica' ? 'selected' : ''); ?>>
                                Continuidad Académica</option>
                            <option value="egresado"
                                <?php echo e($persona->estu_tipo_matricula == 'egresado' ? 'selected' : ''); ?>>Egresado
                            </option>
                        </select>
                        <?php $__errorArgs = ['estu_tipo_matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_matricula"><?php echo e(__('Matricula (Opcional)')); ?></label>
                        <select class="form-control" name="estu_matricula" id="estu_matricula">
                            <option value="">---- SELECCIONE ----</option>
                            <option value="pendiente"
                                <?php echo e($persona->estu_matricula == 'pendiente' ? 'selected' : ''); ?>>
                                Pendiente</option>
                            <option value="pagado" <?php echo e($persona->estu_matricula == 'pagado' ? 'selected' : ''); ?>>
                                Pagado
                            </option>
                            <option value="sin-liquidar"
                                <?php echo e($persona->estu_matricula == 'sin-liquidar' ? 'selected' : ''); ?>>Sin liquidar
                            </option>
                        </select>
                        <?php $__errorArgs = ['estu_matricula'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_pga"><?php echo e(__('Promedio general acumulado ')); ?></label>
                        <input id="estu_pga" type="text" class="form-control <?php $__errorArgs = ['estu_pga'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="estu_pga" value="<?php echo e($persona->estu_pga); ?>" autocomplete="estu_pga" autofocus>
                    </div>
                    <div class="col-md-6">
                        <label for="estu_reconocimiento"><?php echo e(__('Reconocimiento (Opcional)')); ?></label>
                        <input id="estu_reconocimiento" type="number"
                            class="form-control <?php $__errorArgs = ['estu_reconocimiento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="estu_reconocimiento" value="<?php echo e($persona->estu_reconocimiento); ?>"
                            autocomplete="estu_reconocimiento" autofocus>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="estu_egresado"><?php echo e(__('¿Es egresado? ')); ?></label>
                        <div class="row">
                            <div class="col-md-12">
                                <select class="form-control" name="estu_egresado" id="estu_egresado">
                                    <option value="">---- SELECCIONE ----</option>
                                    <option value="Si" <?php echo e($persona->estu_egresado == 'Si' ? 'selected' : ''); ?>>Si
                                    </option>
                                    <option value="No" <?php echo e($persona->estu_egresado == 'No' ? 'selected' : ''); ?>>No
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <label
                            for="estu_administrativo"><?php echo e(__('¿Es personal administrativo de unisangil? ')); ?></label>
                        <div class="row">
                            <div class="col-md-12">
                                <select class="form-control" name="estu_administrativo" id="estu_administrativo">
                                    <option value="">---- SELECCIONE ----</option>
                                    <option value="Si"
                                        <?php echo e($persona->estu_administrativo == 'Si' ? 'selected' : ''); ?>>Si
                                    </option>
                                    <option value="No"
                                        <?php echo e($persona->estu_administrativo == 'No' ? 'selected' : ''); ?>>No
                                    </option>
                                </select>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="mb-3" id="administrativo-estudiante">
                    <h4>Datos administrativos</h4>
                        <hr>
                    <div class="row">
                        <div class="col-md-6 mt-2">
                            <label for="estu_cargo"><?php echo e(__('Cargo')); ?></label>
                            <input id="estu_cargo" type="text"
                                class="form-control <?php $__errorArgs = ['estu_cargo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="estu_cargo"
                                value="<?php echo e($persona->estu_cargo); ?>" autocomplete="estu_cargo" autofocus>
                        </div>
                        <div class="col-md-6 mt-2">
                            <label for="estu_dependencia"><?php echo e(__('Dependencia')); ?></label>
                            <input id="estu_dependencia" type="text"
                                class="form-control <?php $__errorArgs = ['estu_dependencia'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="estu_dependencia" value="<?php echo e($persona->estu_dependencia); ?>"
                                autocomplete="estu_dependencia" autofocus>
                        </div>
                        <div class="col-md-6 mt-2">
                            <label for="estu_fecha_ingreso"><?php echo e(__('Fecha de ingreso')); ?></label>
                            <input id="estu_fecha_ingreso" type="date"
                                class="form-control <?php $__errorArgs = ['estu_fecha_ingreso'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="estu_fecha_ingreso" value="<?php echo e($persona->estu_fecha_ingreso); ?>"
                                autocomplete="estu_fecha_ingreso" autofocus>
                        </div>
                        <div class="col-md-6 mt-2">
                            <label for="estu_no_contrato"><?php echo e(__('No. contrato')); ?></label>
                            <input id="estu_no_contrato" type="text"
                                class="form-control <?php $__errorArgs = ['estu_no_contrato'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="estu_no_contrato" value="<?php echo e($persona->estu_no_contrato); ?>"
                                autocomplete="estu_no_contrato" autofocus>
                        </div>
                        <div class="col-md-6 mt-2">
                            <label for="estu_fecha_final"><?php echo e(__('Fecha de finalización')); ?></label>
                            <input id="estu_fecha_final" type="date"
                                class="form-control <?php $__errorArgs = ['estu_fecha_final'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="estu_fecha_final" value="<?php echo e($persona->estu_fecha_final); ?>"
                                autocomplete="estu_fecha_final" autofocus>
                        </div>
                        <div class="col-md-6 mt-2">
                            <label for="estu_estado_cargo"><?php echo e(__('Estado cargo')); ?></label>
                            <select class="form-control" name="estu_estado_cargo" id="estu_estado_cargo">
                                <option value="" >---- SELECCIONE ----</option>
                                <option value="activo" <?php echo e($persona->estu_estado_cargo == 'activo' ? 'selected' : ''); ?>>Activo</option>
                                <option value="inactivo" <?php echo e($persona->estu_estado_cargo == 'inactivo' ? 'selected' : ''); ?>>Inactivo</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row mb-0">
                    <div class="col-md-12 offset-md-12">
                        <button type="submit" class="btn btn-success">
                            <?php echo e(__('Actualizar')); ?>

                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php $__env->startSection('scripts'); ?>
<script src="/js/admin/programa_plan_estudio.js"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/estudiante/edit.blade.php ENDPATH**/ ?>