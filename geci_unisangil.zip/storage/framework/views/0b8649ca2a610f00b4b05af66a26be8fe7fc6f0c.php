<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/investigacion/mostrargrupo">Grupo</a> / <a href="/investigacion">Investigación</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-table"></i> Módulo Investigación</h1>
    <?php $__env->startSection('message'); ?>
        <p>Listado de grupos de investigación</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<style>
    #card-investigacion {
        text-decoration: none;
    }

    #card-investigacion h4 {
        color: brown;
        font-weight: 900;
    }

    #card-investigacion p {
        color: black;
    }

    #card-investigacion p span {
        font-size: 13px;
        font-style: italic;
    }

</style>
<?php $__env->startSection('content'); ?>
    <div class="container">
        <h3>Grupos de investigación<a class="btn btn-success btn-sm" href="creargrupo"><i
                    class="fa fa-plus-circle"></i> Crear nuevo grupo</a>
            <a class="btn btn-outline-danger" href="<?php echo e(url('investigacion/exportpdfinvestigacion')); ?>"
                title="Generar reporte pdf" target="_blank"><i class="fa fa-file-pdf-o"></i></a>
            <a class="btn btn-outline-success" href="<?php echo e(url('investigacion/exportexcelinvestigacion')); ?>"
                title="Generar reporte excel"><i class="fa fa-file-excel-o"></i></a>
        </h3>
        <hr>
        <?php if($grupos->count() > 0): ?>
            <?php $__currentLoopData = $grupos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $grupo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <a class="card col-md-12 p-3 mt-2" id="card-investigacion"
                    href="/investigacion/<?php echo e($grupo->id); ?>/vergrupo">
                    <h4><?php echo e(Str::upper($grupo->inv_nombre_grupo)); ?></h4>
                    <p><?php echo e($grupo->inv_categoria_grupo == '' ? 'Sin categoria' : $grupo->inv_categoria_grupo); ?><br>
                        <span>Lider grupo:
                            <?php echo e($grupo->personas->per_nombre . ' ' . $grupo->personas->per_apellido); ?></span>
                    </p>
                </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php else: ?>
            <div class="alert alert-primary" role="alert">
                <strong>No se evidencia grupos registrados</strong>
            </div>
        <?php endif; ?>


    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/investigacion/grupo/index.blade.php ENDPATH**/ ?>