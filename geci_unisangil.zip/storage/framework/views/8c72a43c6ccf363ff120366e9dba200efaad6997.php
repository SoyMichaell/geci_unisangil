
<?php $__env->startSection('navegar'); ?>
    <a href="/metodologia/create">Crear</a> / <a href="/metodologia">Metodologia</a>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('title'); ?>
    <h1 class="titulo"><i class="fa fa-cubes"></i> Formulario de registro</h1><!--TODO: Validad icono-->
<?php $__env->startSection('message'); ?>
    <p>Diligencie todos los campos requeridos *.</p>
<?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="tile">
        <h4 class="title"><i class="fa fa-cube"></i> Registro metodologia</h4><hr>
            <form action="/metodologia" method="post">
                <?php echo csrf_field(); ?>
                <div class="row mb-3">
                    <div class="col-md-12">
                        <label for="met_nombre"><?php echo e(__('Metodologia *')); ?></label>
                        <input id="met_nombre" type="text" class="form-control <?php $__errorArgs = ['met_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="met_nombre" value="<?php echo e(old('met_nombre')); ?>" autocomplete="met_nombre"
                            autofocus>
                        <?php $__errorArgs = ['met_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-0">
                    <div class="col-md-12 offset-md-12">
                        <button type="submit" class="btn btn-success">
                            <?php echo e(__('Registrar')); ?>

                        </button>
                    </div>
                </div>
            </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/configuracion/metodologia/create.blade.php ENDPATH**/ ?>