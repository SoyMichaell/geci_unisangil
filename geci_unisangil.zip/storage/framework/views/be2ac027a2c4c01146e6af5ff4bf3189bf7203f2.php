<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/programa//<?php echo e($asignatura->id); ?>editarasignatura">Editar</a> / <a href="/programa/mostrarasignatura">Asignaturas</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-pencil-square-o"></i> Formulario de edición</h1>
    <?php $__env->startSection('message'); ?>
        <p>Diligencie todos los campos requeridos</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container col-md-12">
        <div class="tile">
            <h4 class="titulo"><i class="fa fa-pencil"></i> Actualizar información</h4><hr>
            <form action="/programa/<?php echo e($asignatura->id); ?>/actualizarasignatura" method="post">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="asig_id_sede"><?php echo e(__('Sede *')); ?></label>
                        <select class="form-control" name="asig_id_sede" id="asig_id_sede">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $municipios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $municipio): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($municipio->id); ?>"
                                    <?php echo e($municipio->id == $asignatura->asig_id_sede ? 'selected' : ''); ?>>
                                    <?php echo e($municipio->mun_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <?php $__errorArgs = ['asig_id_sede'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="asig_id_programa"><?php echo e(__('Programa *')); ?></label>
                        <select class="form-control" name="asig_id_programa" id="asig_id_programa">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $programas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $programa): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($programa->id); ?>"
                                    <?php echo e($programa->id == $asignatura->asig_id_programa ? 'selected' : ''); ?>>
                                    <?php echo e($programa->pro_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <small><?php echo e($programas->count() > 0 ? '' : 'No hay programas, primero registre'); ?></small>
                        <?php $__errorArgs = ['asig_id_programa'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="asig_id_plan_estudio"><?php echo e(__('Plan de estudio *')); ?></label>
                        <select class="form-control <?php $__errorArgs = ['asig_id_plan_estudio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="asig_id_plan_estudio" id="asig_id_plan_estudio">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $plans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $plan): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($plan->id); ?>"
                                    <?php echo e($plan->id == $asignatura->asig_id_plan_estudio ? 'selected' : ''); ?>>
                                    <?php echo e($plan->pp_plan); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <p class="badge badge-danger"><?php echo e($plans->count() > 0 ? '' : 'No exiten plan o planes de estudio'); ?></p>
                        <?php $__errorArgs = ['asig_id_plan_estudio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="asig_id_componente"><?php echo e(__('Componente *')); ?></label>
                        <select class="form-control <?php $__errorArgs = ['asig_id_componente'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="asig_id_componente" id="asig_id_componente">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $componentes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $componente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($componente->id); ?>" <?php echo e($asignatura->asig_id_componente == $componente->id ? 'selected' : ''); ?>><?php echo e($componente->cocopa_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <p class="badge badge-danger"><?php echo e($componentes->count() > 0 ? '' : 'No existen componentes registrados'); ?></p>
                        <?php $__errorArgs = ['asig_id_plan_estudio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="asig_id_area"><?php echo e(__('Área *')); ?></label>
                        <select class="form-control <?php $__errorArgs = ['asig_id_area'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="asig_id_area" id="asig_id_area">
                            <option value="">---- SELECCIONE ----</option>
                            <?php $__currentLoopData = $areas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $area): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <option value="<?php echo e($area->id); ?>" <?php echo e($asignatura->asig_id_area == $area->id ? 'selected' : ''); ?>><?php echo e($area->coarpl_nombre); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <p class="badge badge-danger"><?php echo e($areas->count() > 0 ? '' : 'No existen áreas registradas'); ?></p>
                        <?php $__errorArgs = ['asig_id_plan_estudio'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="asig_codigo"><?php echo e(__('Código asignatura *')); ?></label>
                        <input id="asig_codigo" type="text"
                            class="form-control <?php $__errorArgs = ['asig_codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="asig_codigo"
                            value="<?php echo e($asignatura->asig_codigo); ?>" autocomplete="asig_codigo" autofocus>
                        <?php $__errorArgs = ['asig_codigo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="asig_nombre"><?php echo e(__('Nombre asignatura *')); ?></label>
                        <input id="asig_nombre" type="text"
                            class="form-control <?php $__errorArgs = ['asig_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="asig_nombre"
                            value="<?php echo e($asignatura->asig_nombre); ?>" autocomplete="asig_nombre" autofocus>
                        <?php $__errorArgs = ['asig_nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="asig_no_creditos"><?php echo e(__('Número de creditos *')); ?></label>
                        <input id="asig_no_creditos" type="number"
                            class="form-control <?php $__errorArgs = ['asig_no_creditos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="asig_no_creditos"
                            value="<?php echo e($asignatura->asig_no_creditos); ?>" autocomplete="asig_no_creditos" autofocus>
                        <?php $__errorArgs = ['asig_no_creditos'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-6">
                        <label for="asig_no_semanales"><?php echo e(__('Número de horas semanales *')); ?></label>
                        <input id="asig_no_semanales" type="number"
                            class="form-control <?php $__errorArgs = ['asig_no_semanales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                            name="asig_no_semanales" value="<?php echo e($asignatura->asig_no_semanales); ?>"
                            autocomplete="asig_no_semanales" autofocus>
                        <?php $__errorArgs = ['asig_no_semanales'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="col-md-6">
                        <label for="asig_no_semestre"><?php echo e(__('Número de horas semestre *')); ?></label>
                        <input id="asig_no_semestre" type="number"
                            class="form-control <?php $__errorArgs = ['asig_no_semestre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="asig_no_semestre"
                            value="<?php echo e($asignatura->asig_no_semestre); ?>" autocomplete="asig_no_semestre" autofocus>
                        <?php $__errorArgs = ['asig_no_semestre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-3">
                    <div class="col-md-12">
                        <label for="asig_estado"><?php echo e(__('Estado *')); ?></label>
                        <select class="form-control" name="asig_estado" id="asig_estado">
                            <option value="activo" <?php echo e($asignatura->asig_estado == 'activo' ? 'selected' : ''); ?>>Activo
                            </option>
                            <option value="inactivo" <?php echo e($asignatura->asig_estado == 'inactivo' ? 'selected' : ''); ?>>
                                Inactivo</option>
                        </select>
                        <?php $__errorArgs = ['asig_estado'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="invalid-feedback" role="alert">
                                <strong><?php echo e($message); ?></strong>
                            </span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="row mb-0">
                    <div class="col-md-12 offset-md-12">
                        <button type="submit" class="btn btn-success">
                            <?php echo e(__('Actualizar')); ?>

                        </button>
                    </div>
                </div>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/programa/asignatura/edit.blade.php ENDPATH**/ ?>