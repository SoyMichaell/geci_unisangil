<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/prueba/<?php echo e($saber->id); ?>/versaber">Vista</a> / <a href="/prueba/mostrarsaber">Saber 11</a> / <a href="/prueba">Pruebas saber</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-book"></i> Visualizar información</h1>
    <?php $__env->startSection('message'); ?>
        <p>Información de registro.</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<style>
    #prueba-saber-ul{
        list-style: none;
    }
    #prueba-saber-ul li {
        font-size: 18px;
    }
</style>
<?php $__env->startSection('content'); ?>
    <div class="container bg-white p-3">
        <h5><i class="fa fa-question-circle-o"></i> Información prueba saber 11</h5><hr>
        <div class="row">
            <div class="col-md-5">
                <ul id="prueba-saber-ul">
                    <li><strong>Nombre completo: </strong><?php echo e($saber->per_nombre . ' ' . $saber->per_apellido); ?></li>
                    <li><strong>Año de presentación: </strong><?php echo e($saber->prueba_saber_year); ?></li>
                    <li><strong>Periodo: </strong><?php echo e($saber->prueba_saber_periodo); ?></li>
                    <li><strong>Puntaje global: </strong><?php echo e(number_format($saber->prueba_saber_puntaje_global, 2)); ?>

                    </li>
                </ul>
            </div>
            <div class="col-md-7">
                <table class="table table-bordered">
                    <tr>
                        <th>Módulo</th>
                        <th>Puntaje</th>
                    </tr>
                    <?php $__currentLoopData = $saberes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $saberx): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <th>Módulo <?php echo e($saberx->tipo_modulo_nombre); ?></th>
                            <td><?php echo e($saberx->prsamo_puntaje); ?></td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </table>
            </div>
        </div>

    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/prueba/saber/show.blade.php ENDPATH**/ ?>