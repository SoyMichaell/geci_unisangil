<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/practica">Practica Laboral</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-table"></i> Módulo Practicas Laborales</h1>
    <?php $__env->startSection('message'); ?>
        <p>Listado de practicas laborales docentes / estudiantes</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="tile col-md-12 mt-2">
            <div class="row mb-3">
                <div class="col-md-6">
                    <h4>Lista de registros</h4>
                </div>
                <div class="col-md-6 d-flex justify-content-end align-items-center" style="margin-left: -30px">
                    <div class="dropdown">
                        <a class="btn btn-outline-danger" style="border-radius: 100%" href="#" role="button"
                            id="dropdownMenuLink" data-toggle="dropdown" aria-expanded="false">
                            <i class="fa fa-file-pdf-o"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <a class="dropdown-item" href="<?php echo e(url('practica/exportpdf')); ?>" target="_blank">Practica
                                laboral general</a>
                            <a class="dropdown-item" href="<?php echo e(url('practica/exportdocentepdf')); ?>"
                                target="_blank">Practica laboral
                                docentes</a>
                            <a class="dropdown-item" href="<?php echo e(url('practica/exportestudiantepdf')); ?>"
                                target="_blank">Practica laboral
                                estudiantes</a>
                        </div>
                    </div>
                    <div class="dropdown">
                        <a class="btn btn-outline-success" style="border-radius: 100%" href="#" role="button"
                            id="dropdownMenuLink" data-toggle="dropdown" aria-expanded="false">
                            <i class="fa fa-file-pdf-o"></i>
                        </a>
                        <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            <a class="dropdown-item" href="<?php echo e(url('practica/exportexcel')); ?>">Practica laboral
                                general</a>
                            <a class="dropdown-item" href="<?php echo e(url('practica/expordocenteexcel')); ?>">Practica laboral
                                docentes</a>
                            <a class="dropdown-item" href="<?php echo e(url('practica/exportestudianteexcel')); ?>">Practica
                                laboral
                                estudiantes</a>
                        </div>
                    </div>
                    <a class="btn btn-outline-success" href="<?php echo e(url('practica/create')); ?>"><i
                            class="fa fa-plus-circle"></i>
                        Nuevo</a>
                </div>
            </div>
            <div class="table-responsive mt-2">
                <table class="table" id="tables">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Año</th>
                            <th>Rol</th>
                            <th>Nombre completo</th>
                            <th>Razón social</th>
                            <th>Nit</th>
                            <th>Pais</th>
                            <th>Departamento</th>
                            <th>Ciudad</th>
                            <th>Dirección</th>
                            <th>Telefono</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $i = 1; ?>
                        <?php $__currentLoopData = $practicas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $practica): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($i++); ?></td>
                                <td><?php echo e($practica->prac_year); ?></td>
                                <td><?php echo e(Str::ucfirst($practica->prac_rol)); ?></td>
                                <td><?php echo e($practica->per_nombre . ' ' . $practica->per_apellido); ?></td>
                                <td><?php echo e($practica->prac_razon_social); ?></td>
                                <td><?php echo e($practica->prac_nit_empresa); ?></td>
                                <td><?php echo e($practica->prac_pais); ?></td>
                                <td><?php echo e($practica->prac_departamento); ?></td>
                                <td><?php echo e($practica->prac_ciudad); ?></td>
                                <td><?php echo e($practica->prac_direccion); ?></td>
                                <td><?php echo e($practica->prac_telefono); ?></td>
                                <td>
                                    <form action="<?php echo e(route('practica.destroy', $practica->id)); ?>" method="POST">
                                        <div class="d-flex">
                                            <a class="btn btn-sm" href="/practica/<?php echo e($practica->id); ?>"><i
                                                    class="fa fa-folder-open"></i></a>
                                            <a class="btn btn-outline-info btn-sm "
                                                href="/practica/<?php echo e($practica->id); ?>/edit"><i
                                                    class="fa fa-refresh"></i></a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"><i
                                                    class="fa fa-trash"></i></button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/practica/index.blade.php ENDPATH**/ ?>