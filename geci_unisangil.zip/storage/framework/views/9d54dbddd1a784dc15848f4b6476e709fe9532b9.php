<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/prueba/<?php echo e($resultado->id); ?>/verrresultado">Vista</a> / <a href="/prueba/mostrarresultado">Resultado
            programa</a> / <a href="/prueba">Pruebas saber</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-book"></i> Visualizar información</h1>
    <?php $__env->startSection('message'); ?>
        <p>Diligenciar todos los campos requeridos.</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container tile">
        <h4><i class="fa fa-question-circle-o"></i> Vista de registro</h4><hr>
        <table class="table table-bordered">
            <tr>
                <th>Programa: </th>
                <td><?php echo e(Str::upper($resultado->pro_nombre)); ?></td>
            </tr>
            <tr>
                <th>Codigo SNIES: </th>
                <td><?php echo e($resultado->pro_codigosnies); ?></td>
            </tr>
            <tr>
                <th>Grupo de referencia: </th>
                <td><?php echo e(Str::upper($resultado->pro_grupo_referencia)); ?></td>
            </tr>
            <tr>
                <th>Grupo de referencia (NBC)</th>
                <td><?php echo e(Str::upper($resultado->pro_grupo_referencia_nbc)); ?></td>
            </tr>
        </table>
        <div class="alert alert-primary" role="alert">
            RESULTADOS GLOBALES <a href="/prueba/crearresultado" class="alert-link">Nuevo</a>
        </div>
        <table class="table table-bordered">
            <tr>
                <th>Nivel de agregación</th>
                <td class="text-center fw-bold"><?php echo e($resultado->prurepro_year); ?></td>
            </tr>
            <tr>
                <th>Programa</th>
                <td class="text-center"><?php echo e($resultado->prurepro_global_programa); ?></td>
            </tr>
            <tr>
                <th>Institución</th>
                <td class="text-center"><?php echo e($resultado->prurepro_global_institucion); ?></td>
            </tr>
            <tr>
                <th>Sede</th>
                <td class="text-center"><?php echo e($resultado->prurepro_global_sede); ?></td>
            </tr>
            <tr>
                <th>Grupo de referencia NBC</th>
                <td class="text-center"><?php echo e($resultado->prurepro_global_grupo_referencia); ?></td>
            </tr>
        </table>
        <div class="alert alert-primary" role="alert">
            MÓDULO DE COMPETENCIAS GENÉRICAS <a href="/prueba/crearresultado" class="alert-link">Nuevo</a>
        </div>
        <table class="table table-bordered">
            <tr>
                <th>Nivel de agregación</th>
                <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultadox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($resultadox->tipo_modulo_nombre); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <th>Programa</th>
                <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultadox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($resultadox->prureprono_puntaje_programa); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <th>Institución</th>
                <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultadox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($resultadox->prureprono_puntaje_institucion); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <th>Sede</th>
                <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultadox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($resultadox->prureprono_puntaje_sede); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
            <tr>
                <th>Grupo de referencia NBC</th>
                <?php $__currentLoopData = $resultados; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $resultadox): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <td><?php echo e($resultadox->prureprono_puntaje_grupo_referencia); ?></td>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tr>
        </table>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/prueba/general/show.blade.php ENDPATH**/ ?>