<?php if(!Auth::check()): ?>
    <?php echo $__env->make('home', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php else: ?>
    
    <?php $__env->startSection('navegar'); ?>
        <a href="/docente/<?php echo e($persona->id); ?>/mostrarevaluacion">Evaluación</a> / <a href="/docente">Docente</a>
    <?php $__env->stopSection(); ?>
    <?php $__env->startSection('title'); ?>
        <h1 class="titulo"><i class="fa fa-cubes"></i> Módulo docentes | evaluación</h1>
    <?php $__env->startSection('message'); ?>
        <p>Listado evaluación docente</p>
    <?php $__env->stopSection(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <div class="row mb-1">
            <div class="col-md-12 tile">
                <h4>Lista de registros</h4> <!-- TODO: arreglar botones pdf y excel-->
                <table class="table" id="tables">
                    <thead>
                        <tr>
                            <th>Año</th>
                            <th>Semestre</th>
                            <th>Cal. Autoevaluación</th>
                            <th>Cal. Heteroevaluación</th>
                            <th>Cal. Coevaluación</th>
                            <th>Total promedio</th>
                            <th>Observación</th>
                            <th>Documento</th>
                            <th>Acciones</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $evaluacions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evaluacion): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($evaluacion->doe_year); ?></td>
                                <td><?php echo e($evaluacion->doe_semestre); ?></td>
                                <td><?php echo e($evaluacion->doe_cal_auto); ?></td>
                                <td><?php echo e($evaluacion->doe_cal_hete); ?></td>
                                <td><?php echo e($evaluacion->doe_cal_coe); ?></td>
                                <td><?php echo e($evaluacion->doe_total_pro); ?></td>
                                <td><?php echo e($evaluacion->doe_observacion); ?></td>
                                <td>
                                    <a href="<?php echo e(asset('/docente/evaluacion/' . $evaluacion->doe_url_evaluacion)); ?>"
                                        target="_blank"><?php echo e($evaluacion->doe_url_evaluacion); ?></a>
                                </td>
                                <td>
                                    <form action="<?php echo e(url("docente/{$evaluacion->id}/eliminarevaluacion")); ?>"
                                        method="POST">
                                        <div class="d-flex">
                                            <a class="btn btn-outline-info btn-sm"
                                                href="/docente/<?php echo e($persona->id); ?>/<?php echo e($evaluacion->id); ?>/editarevaluacion"><i
                                                    class="fa fa-refresh"></i></a>
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('DELETE'); ?>
                                            <button type="submit" class="btn btn-danger btn-sm"><i
                                                    class="fa fa-trash"></i></button>
                                        </div>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
        <div class="row mb-3">
            <div class="col-md-12 tile">
                <h4><i class="fa fa-cubes"></i> Registro evaluación docente</h4>
                <hr>
                <form action="/docente/registroevaluacion" method="post" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="doe_persona_docente" id="doe_persona_docente"
                        value="<?php echo e($persona->id); ?>">
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="doe_year"><?php echo e(__('Año *')); ?></label>
                            <input id="doe_year" type="number"
                                class="form-control <?php $__errorArgs = ['doe_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="doe_year"
                                value="<?php echo e(old('doe_year')); ?>" autocomplete="doe_year">
                            <?php $__errorArgs = ['doe_year'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="doe_semestre"><?php echo e(__('Semestre *')); ?></label>
                            <select class="form-control <?php $__errorArgs = ['doe_semestre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="doe_semestre"
                                id="doe_semestre">
                                <option value="">---- SELECCIONE ----</option>
                                <option value="1">1</option>
                                <option value="2">2</option>
                                <option value="3">3</option>
                                <option value="4">4</option>
                                <option value="5">5</option>
                                <option value="6">6</option>
                                <option value="7">7</option>
                                <option value="8">8</option>
                                <option value="9">9</option>
                                <option value="10">10</option>
                            </select>
                            <?php $__errorArgs = ['doe_semestre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="doe_cal_auto"><?php echo e(__('Calificación Autoevaluación *')); ?></label>
                            <input id="doe_cal_auto" type="text"
                                class="form-control <?php $__errorArgs = ['doe_cal_auto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="doe_cal_auto"
                                value="<?php echo e(old('doe_cal_auto')); ?>" autocomplete="doe_cal_auto">
                            <?php $__errorArgs = ['doe_cal_auto'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="doe_cal_hete"><?php echo e(__('Calificación Heroevaluación *')); ?></label>
                            <input id="doe_cal_hete" type="text"
                                class="form-control <?php $__errorArgs = ['doe_cal_hete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="doe_cal_hete"
                                value="<?php echo e(old('doe_cal_hete')); ?>" autocomplete="doe_cal_hete">
                            <?php $__errorArgs = ['doe_cal_hete'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="doe_cal_coe"><?php echo e(__('Calificación Coevaluación *')); ?></label>
                            <input id="doe_cal_coe" type="text"
                                class="form-control <?php $__errorArgs = ['doe_cal_coe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="doe_cal_coe"
                                value="<?php echo e(old('doe_cal_coe')); ?>" autocomplete="doe_cal_coe">
                            <?php $__errorArgs = ['doe_cal_coe'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label for="doe_total_pro"><?php echo e(__('Total promedio *')); ?></label>
                            <input id="doe_total_pro" type="text"
                                class="form-control <?php $__errorArgs = ['doe_total_pro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="doe_total_pro"
                                value="<?php echo e(old('doe_total_pro')); ?>" autocomplete="doe_total_pro">
                            <?php $__errorArgs = ['doe_total_pro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-3">
                        <div class="col-md-6">
                            <label for="doe_observacion"><?php echo e(__('Observación *')); ?></label>
                            <textarea class="form-control <?php $__errorArgs = ['doe_total_pro'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="doe_observacion" id="doe_observacion"
                                cols="30" rows="10"></textarea>
                            <?php $__errorArgs = ['doe_observacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <div class="col-md-6">
                            <label
                                for="doe_url_evaluacion"><?php echo e(__('Cargar .pdf de soporte evaluación docente *')); ?></label>
                            <input id="doe_url_evaluacion" type="file"
                                class="form-control <?php $__errorArgs = ['doe_url_evaluacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"
                                name="doe_url_evaluacion" value="<?php echo e(old('doe_url_evaluacion')); ?>"
                                autocomplete="doe_url_evaluacion">
                            <?php $__errorArgs = ['doe_url_evaluacion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="invalid-feedback" role="alert">
                                    <strong><?php echo e($message); ?></strong>
                                </span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    <div class="row mb-0 mt-2">
                        <div class="col-md-12 offset-md-12">
                            <button type="submit" class="btn btn-success">
                                <?php echo e(__('Registrar')); ?>

                            </button>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php endif; ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\MICHAEL\Desktop\geci_unisangil\resources\views/docente/evaluacion/index.blade.php ENDPATH**/ ?>